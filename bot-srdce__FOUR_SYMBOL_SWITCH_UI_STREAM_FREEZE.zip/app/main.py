import os
import time
import json
import asyncio
import inspect
import datetime
import logging
from dataclasses import dataclass
from typing import Optional, List, Dict, Any, Tuple, Set

from fastapi import FastAPI, Query, Body
from fastapi.middleware.cors import CORSMiddleware

from pocketoptionapi_async import AsyncPocketOptionClient
from playwright.async_api import async_playwright

logging.getLogger("pocketoptionapi_async").setLevel(logging.ERROR)
logging.getLogger("websockets").setLevel(logging.ERROR)
logging.getLogger("playwright").setLevel(logging.ERROR)

try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None

APP_NAME = "New Chance"

TF_SEC = int(os.getenv("PO_TF_SEC", "60"))
SYMBOL_DEFAULT = os.getenv("PO_SYMBOL", "CHFJPY_otc")
IS_DEMO = os.getenv("PO_IS_DEMO", "1").strip() in ("1", "true", "True", "yes", "YES")
LOCAL_TZ = os.getenv("LOCAL_TZ", "Europe/Prague")
SSID_FILE = os.getenv("PO_SSID_FILE", "po_ssid.txt")

FRESH_MAX_SEC = int(os.getenv("PO_FRESH_MAX_SEC", "120"))
PO_TIME_OFFSET_SEC = int(os.getenv("PO_TIME_OFFSET_SEC", "7200"))

PO_USE_PW = os.getenv("PO_USE_PLAYWRIGHT", "1").strip() in ("1", "true", "True", "yes", "YES")
PO_PW_HEADLESS = os.getenv("PO_PW_HEADLESS", "0").strip() in ("1", "true", "True", "yes", "YES")
PO_PW_URL = os.getenv("PO_PW_URL", "https://pocketoption.com/en/cabinet/demo-quick-high-low/").strip()
PO_PW_PROFILE_DIR = os.path.expanduser(os.getenv("PO_PW_PROFILE_DIR", "~/.newchance_pw_profile"))
PO_PW_BROWSER = os.getenv("PO_PW_BROWSER", "webkit").strip().lower()  # chromium | webkit

# Warmup
WARMUP_GRACE_SEC = float(os.getenv("PO_WARMUP_GRACE_SEC", "2"))

# HA seed
HA_SEED_FILE = os.getenv("PO_HA_SEED_FILE", "ha_seed.json")

# WATCHDOG (AUTO, with start-grace)
WD_ENABLED = os.getenv("PO_WD_ENABLED", "1").strip() in ("1", "true", "True", "yes", "YES")
WD_TICK_MAX_AGE_SEC = float(os.getenv("PO_WD_TICK_MAX_AGE_SEC", "8"))
WD_FAILS_REQUIRED = int(os.getenv("PO_WD_FAILS_REQUIRED", "3"))
WD_COOLDOWN_SEC = float(os.getenv("PO_WD_COOLDOWN_SEC", "60"))
WD_START_GRACE_SEC = float(os.getenv("PO_WD_START_GRACE_SEC", "360"))  # ignore no_ticks_yet this long after engine start

print(f"LOADED New Chance main.py WATCHDOG+GRACE ✅ browser={PO_PW_BROWSER} symbol={SYMBOL_DEFAULT}")


def _now_ts() -> int:
    return int(time.time())


def _align(ts: int) -> int:
    return ts - (ts % TF_SEC)


def _fmt(ts_epoch: int) -> str:
    try:
        if ZoneInfo:
            dt = datetime.datetime.fromtimestamp(ts_epoch, tz=ZoneInfo(LOCAL_TZ))
        else:
            dt = datetime.datetime.fromtimestamp(ts_epoch)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(ts_epoch)


def _open_close_str(ts_open: int) -> Tuple[str, str]:
    return _fmt(ts_open), _fmt(ts_open + TF_SEC)


def _age_sec(ts_open: int) -> int:
    close_ts = ts_open + TF_SEC
    age = _now_ts() - close_ts
    return 0 if age < 0 else int(age)


def _read_ssid() -> Optional[str]:
    ssid_env = os.getenv("PO_SSID")
    if ssid_env and ssid_env.strip():
        return ssid_env.strip()
    try:
        with open(SSID_FILE, "r", encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if ln:
                    return ln
        return None
    except Exception:
        return None


def _norm(s: str) -> str:
    s = (s or "").lower()
    out = []
    for ch in s:
        if ch.isalnum():
            out.append(ch)
    return "".join(out)


@dataclass
class StreamStats:
    ticks_seen: int = 0
    last_tick_local: Optional[float] = None
    last_tick_ts_raw: Optional[float] = None
    last_tick_ts_used: Optional[float] = None
    last_tick_price: Optional[float] = None


@dataclass
class TickFeedStats:
    enabled: bool = PO_USE_PW
    running: bool = False
    last_err: str = "—"
    url: str = PO_PW_URL
    headless: bool = PO_PW_HEADLESS
    profile_dir: str = PO_PW_PROFILE_DIR
    browser: str = PO_PW_BROWSER

    ws_seen: int = 0
    frames_seen: int = 0
    frames_last_ts: Optional[float] = None

    pending_event: Optional[str] = None
    pending_ts: Optional[float] = None

    asset_id_for_symbol: Optional[int] = None
    asset_map_size: int = 0

    last_tick_event: Optional[str] = None
    tick_time_mode: str = "unknown"

    ticks_seen: int = 0
    last_price: Optional[float] = None
    last_tick_ts_raw: Optional[float] = None
    last_tick_ts_used: Optional[float] = None
    last_tick_local_ts: Optional[float] = None
    last_tick_age_sec: Optional[float] = None

    warmup_active: bool = False
    warmup_until_open_ts: Optional[int] = None
    warmup_note: str = "—"

    frames_tail: List[Dict[str, Any]] = None


MULTI_SYMBOLS = [
    "AUDNZD_otc",
    "CADCHF_otc",
    "EURCHF_otc",
    "CHFJPY_otc",
]


@dataclass
class SymbolState:
    history_closed: List[Dict[str, Any]] = None
    stream_current: Optional[Dict[str, Any]] = None
    stream_closed: List[Dict[str, Any]] = None
    stream: StreamStats = None
    active_mode: str = "HISTORY"
    history_age_sec: Optional[int] = None
    stream_age_sec: Optional[int] = None


@dataclass
class State:
    running: bool = False
    connected: bool = False
    symbol: str = SYMBOL_DEFAULT
    symbols: List[str] = None
    by_symbol: Dict[str, SymbolState] = None
    is_demo: bool = IS_DEMO
    tf_sec: int = TF_SEC
    local_tz: str = LOCAL_TZ
    fresh_max_sec: int = FRESH_MAX_SEC
    po_time_offset_sec: int = PO_TIME_OFFSET_SEC

    last_connect_error: str = "—"
    last_candles_error: str = "—"
    last_fetch_count: int = 0
    last_poll_ts: Optional[float] = None

    history_closed: List[Dict[str, Any]] = None

    stream_current: Optional[Dict[str, Any]] = None
    stream_closed: List[Dict[str, Any]] = None
    stream: StreamStats = None

    active_mode: str = "HISTORY"
    history_age_sec: Optional[int] = None
    stream_age_sec: Optional[int] = None

    tick_feed: TickFeedStats = None

    # watchdog telemetry
    wd_enabled: bool = WD_ENABLED
    wd_tick_max_age_sec: float = WD_TICK_MAX_AGE_SEC
    wd_fails_required: int = WD_FAILS_REQUIRED
    wd_cooldown_sec: float = WD_COOLDOWN_SEC
    wd_start_grace_sec: float = WD_START_GRACE_SEC

    wd_bad_count: int = 0
    wd_last_restart_ts: Optional[float] = None
    wd_last_reason: str = "—"
    wd_engine_start_ts: Optional[float] = None


app = FastAPI(title=APP_NAME)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

STATE = State(
    symbols=list(MULTI_SYMBOLS),
    by_symbol={
        sym: SymbolState(
            history_closed=[],
            stream_current=None,
            stream_closed=[],
            stream=StreamStats(),
            active_mode="HISTORY",
            history_age_sec=None,
            stream_age_sec=None,
        )
        for sym in MULTI_SYMBOLS
    },
    history_closed=[],
    stream_current=None,
    stream_closed=[],
    stream=StreamStats(),
    tick_feed=TickFeedStats(frames_tail=[]),
)

_engine_task: Optional[asyncio.Task] = None
_tick_task: Optional[asyncio.Task] = None
_stop_event = asyncio.Event()
_lock = asyncio.Lock()
_TICK_FEED_RUN_ID = 0
_PW_CTX = None
_PW_PAGE = None

_ASSET_ID_TO_SYMBOL: Dict[int, str] = {}
_SEEN_SYMBOLS: Set[str] = set()

_HA_SEEDS: Dict[str, Dict[str, Any]] = {}


def _get_symbol_state(symbol: Optional[str] = None) -> SymbolState:
    sym = symbol or STATE.symbol
    by_symbol = getattr(STATE, "by_symbol", None) or {}
    ss = by_symbol.get(sym)
    if ss is None:
        ss = SymbolState(
            history_closed=[],
            stream_current=None,
            stream_closed=[],
            stream=StreamStats(),
            active_mode="HISTORY",
            history_age_sec=None,
            stream_age_sec=None,
        )
        by_symbol[sym] = ss
        STATE.by_symbol = by_symbol
    if ss.history_closed is None:
        ss.history_closed = []
    if ss.stream_closed is None:
        ss.stream_closed = []
    if ss.stream is None:
        ss.stream = StreamStats()
    return ss


def _get_history_closed(symbol: Optional[str] = None) -> List[Dict[str, Any]]:
    return _get_symbol_state(symbol).history_closed or []


def _get_stream_closed(symbol: Optional[str] = None) -> List[Dict[str, Any]]:
    return _get_symbol_state(symbol).stream_closed or []


def _get_stream_current(symbol: Optional[str] = None) -> Optional[Dict[str, Any]]:
    return _get_symbol_state(symbol).stream_current


def _load_ha_seeds() -> None:
    global _HA_SEEDS
    try:
        if not os.path.exists(HA_SEED_FILE):
            _HA_SEEDS = {}
            return
        with open(HA_SEED_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        _HA_SEEDS = data if isinstance(data, dict) else {}
    except Exception:
        _HA_SEEDS = {}


def _save_ha_seeds() -> None:
    try:
        with open(HA_SEED_FILE, "w", encoding="utf-8") as f:
            json.dump(_HA_SEEDS, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# --- AUTOSAVE HA SEED (fresh) -----------------------------------------------

from typing import Optional
import sqlite3
from pathlib import Path
from fastapi.responses import HTMLResponse
import urllib.request
import urllib.parse
import ssl
import threading
_LAST_AUTOSAVED_SEED_TS: Optional[int] = None

def _autosave_ha_seed_from_last_closed(reason: str = "autosave") -> bool:
    """Persist a fresh HA seed based on a closed candle.

    IMPORTANT:
    - For minute_close, do NOT persist the just-closed candle as seed.
      That would make the current candle self-seeded on /api/last.
    - Instead, persist the PREVIOUS closed candle, so the newest candle
      is always chained from prev_ha like Pocket does.
    """
    global _LAST_AUTOSAVED_SEED_TS

    closed = STATE.stream_closed if getattr(STATE, "active_mode", None) == "STREAM" else STATE.history_closed
    if not closed:
        return False

    candidates = list(closed)

    # Fix self-seed:
    # after appending a newly closed candle, seed the PREVIOUS one
    # so the latest candle is derived from prev_ha, not from itself.
    if reason == "minute_close":
        if len(candidates) < 2:
            return False
        candidates = candidates[:-1]

    # pick last minute-aligned closed candle from candidates
    last = None
    for _c in reversed(candidates):
        try:
            _ts = int((_c.get("timestamp") if isinstance(_c, dict) else getattr(_c, "timestamp", 0)) or 0)
        except Exception:
            _ts = 0
        if _ts > 0 and (_ts % 60) == 0:
            last = _c
            break

    if last is None:
        last = candidates[-1]

    try:
        last_with_ha = _attach_ha(dict(last))
    except Exception:
        return False

    ts = int(last_with_ha.get("timestamp") or 0)
    ha_open = last_with_ha.get("ha_open")
    ha_close = last_with_ha.get("ha_close")

    if ts <= 0 or ha_open is None or ha_close is None:
        return False

    if _LAST_AUTOSAVED_SEED_TS == ts:
        return False

    sym = getattr(STATE, "symbol", None) or last_with_ha.get("symbol")
    if not sym:
        return False

    _HA_SEEDS[sym] = {
        "timestamp": ts,
        "ha_open": float(ha_open),
        "ha_close": float(ha_close),
        "updated_at": time.time(),
        "reason": reason,
    }
    _save_ha_seeds()
    _LAST_AUTOSAVED_SEED_TS = ts
    return True
_load_ha_seeds()


def _get_seed_for_symbol(symbol: str) -> Optional[Dict[str, Any]]:
    s = _HA_SEEDS.get(symbol)
    return s if isinstance(s, dict) else None


def _history_limit_from_seed(default: int = 120, maximum: int = 1500) -> int:
    seed = _get_seed_for_symbol(STATE.symbol)
    if not isinstance(seed, dict):
        return default
    try:
        seed_ts = int(seed.get("timestamp") or 0)
    except Exception:
        return default
    if seed_ts <= 0:
        return default
    age_sec = max(0, int(time.time()) - seed_ts)
    need = int(age_sec // 60) + 20
    if need < default:
        return default
    if need > maximum:
        return maximum
    return need


def _pick_last_history(symbol: Optional[str] = None) -> Optional[Dict[str, Any]]:
    ss = _get_symbol_state(symbol)
    return ss.history_closed[-1] if ss.history_closed else None


def _pick_last_stream_closed(symbol: Optional[str] = None) -> Optional[Dict[str, Any]]:
    ss = _get_symbol_state(symbol)
    return ss.stream_closed[-1] if ss.stream_closed else None


def _update_hybrid_choice() -> None:
    ss = _get_symbol_state()
    h = _pick_last_history()
    s = _pick_last_stream_closed()
    ss.history_age_sec = _age_sec(int(h["timestamp"])) if h else None
    ss.stream_age_sec = _age_sec(int(s["timestamp"])) if s else None

    tf = STATE.tick_feed
    tick_fresh = (tf.last_tick_local_ts is not None) and ((time.time() - tf.last_tick_local_ts) <= 3.0)
    stream_ready = s is not None and len(_get_stream_closed()) >= 2

    # IMPORTANT:
    # After restart, first closed STREAM candle acts as bridge for HA chaining.
    # Switch output to STREAM only when we have at least 2 closed STREAM candles.
    if tick_fresh and stream_ready:
        ss.active_mode = "STREAM"
        STATE.active_mode = ss.active_mode
        STATE.history_age_sec = ss.history_age_sec
        STATE.stream_age_sec = ss.stream_age_sec
        return

    if ss.history_age_sec is not None and ss.history_age_sec <= STATE.fresh_max_sec:
        ss.active_mode = "HISTORY"
    else:
        ss.active_mode = "STREAM" if stream_ready else "HISTORY"

    STATE.active_mode = ss.active_mode
    STATE.history_age_sec = ss.history_age_sec
    STATE.stream_age_sec = ss.stream_age_sec


def _active_last_closed() -> Optional[Dict[str, Any]]:
    if STATE.active_mode == "STREAM":
        return _pick_last_stream_closed() or _pick_last_history()
    return _pick_last_history() or _pick_last_stream_closed()


def _append_stream_closed(c: Dict[str, Any], symbol: Optional[str] = None) -> None:
    ss = _get_symbol_state(symbol)
    lst = ss.stream_closed or []
    lst.append(c)
    if len(lst) > 500:
        lst = lst[-500:]
    ss.stream_closed = lst


def _calibrate_tick_ts(ts_raw: float) -> Tuple[float, str]:
    now = time.time()
    diff = ts_raw - now
    if abs(diff - float(STATE.po_time_offset_sec)) <= 600:
        return (ts_raw - float(STATE.po_time_offset_sec), "minus_offset")
    if abs(diff) <= 600:
        return (ts_raw, "raw")
    return (ts_raw, "unknown")


def _ts_open_from_tick(ts_used: float) -> int:
    return _align(int(ts_used))


def _maybe_init_warmup(ts_used: float) -> None:
    tf = STATE.tick_feed
    if tf.warmup_until_open_ts is not None:
        return

    ts_open = _ts_open_from_tick(ts_used)
    sec_into_minute = float(ts_used) - float(ts_open)

    if sec_into_minute <= WARMUP_GRACE_SEC:
        tf.warmup_active = False
        tf.warmup_until_open_ts = ts_open
        tf.warmup_note = f"disabled (start at +{sec_into_minute:.2f}s)"
        return

    tf.warmup_active = True
    tf.warmup_until_open_ts = ts_open + TF_SEC
    tf.warmup_note = f"active until {_fmt(tf.warmup_until_open_ts)} (start at +{sec_into_minute:.2f}s)"


def _start_new_stream_candle(ts_open: int, price: float, symbol: Optional[str] = None) -> None:
    sym = symbol or STATE.symbol
    ss = _get_symbol_state(sym)
    ss.stream_current = {
        "symbol": STATE.symbol,
        "timestamp": ts_open,
        "open": float(price),
        "high": float(price),
        "low": float(price),
        "close": float(price),
        "volume": 1.0,
        "source": "STREAM_FORMING",
        "open_time": _open_close_str(ts_open)[0],
        "close_time": _open_close_str(ts_open)[1],
    }


def _on_tick_for_symbol(symbol: str, ts_raw: float, price: float, event_name: Optional[str] = None) -> None:
    sym = symbol
    ts_used, mode = _calibrate_tick_ts(float(ts_raw))
    tf = STATE.tick_feed
    if sym == STATE.symbol:
        _maybe_init_warmup(ts_used)

        STATE.stream.ticks_seen += 1
        STATE.stream.last_tick_local = time.time()
        STATE.stream.last_tick_ts_raw = float(ts_raw)
        STATE.stream.last_tick_ts_used = float(ts_used)
        STATE.stream.last_tick_price = float(price)

        tf.ticks_seen += 1
        tf.last_price = float(price)
        tf.last_tick_ts_raw = float(ts_raw)
        tf.last_tick_ts_used = float(ts_used)
        tf.last_tick_local_ts = time.time()
        tf.last_tick_age_sec = 0.0
        tf.last_tick_event = event_name or tf.last_tick_event
        tf.tick_time_mode = mode

    ts_open = _ts_open_from_tick(ts_used)
    ss = _get_symbol_state(sym)
    cur = ss.stream_current

    if tf.warmup_active and tf.warmup_until_open_ts is not None:
        if ts_open < tf.warmup_until_open_ts:
            if cur is None or int(cur["timestamp"]) != ts_open:
                _start_new_stream_candle(ts_open, price)
            else:
                cur["high"] = max(cur["high"], float(price))
                cur["low"] = min(cur["low"], float(price))
                cur["close"] = float(price)
                cur["volume"] = float(cur.get("volume", 0.0) + 1.0)
                ss.stream_current = cur
            return

        if ts_open == tf.warmup_until_open_ts:
            tf.warmup_active = False
            tf.warmup_note = f"done at {_fmt(ts_open)}"
            _start_new_stream_candle(ts_open, price)
            # warmup_done autosave disabled; keep last persisted minute_close seed
            return

        tf.warmup_active = False
        tf.warmup_note = f"forced-off at {_fmt(ts_open)}"

    if cur and int(cur["timestamp"]) == ts_open:
        cur["high"] = max(cur["high"], float(price))
        cur["low"] = min(cur["low"], float(price))
        cur["close"] = float(price)
        cur["volume"] = float(cur.get("volume", 0.0) + 1.0)
        ss.stream_current = cur
        return

    if cur and cur.get("timestamp") is not None:
        prev_ts = int(cur["timestamp"])
        o, c = _open_close_str(prev_ts)
        closed = {
            "symbol": sym,
            "timestamp": prev_ts,
            "open": float(cur["open"]),
            "high": float(cur["high"]),
            "low": float(cur["low"]),
            "close": float(cur["close"]),
            "volume": float(cur.get("volume", 0.0)),
            "source": "STREAM",
            "open_time": o,
            "close_time": c,
            "age_sec": _age_sec(prev_ts),
        }
        _append_stream_closed(closed)
        _autosave_ha_seed_from_last_closed(reason="minute_close")

        last_close = float(cur["close"])
        gap_ts = prev_ts + 60
        while gap_ts < ts_open:
            go, gc = _open_close_str(gap_ts)
            gap_closed = {
                "symbol": sym,
                "timestamp": gap_ts,
                "open": last_close,
                "high": last_close,
                "low": last_close,
                "close": last_close,
                "volume": 0.0,
                "source": "STREAM_GAP_FILL",
                "open_time": go,
                "close_time": gc,
                "age_sec": _age_sec(gap_ts),
            }
            _append_stream_closed(gap_closed)
            _autosave_ha_seed_from_last_closed(reason="minute_close")
            gap_ts += 60

    _start_new_stream_candle(ts_open, price)


def _parse_json_from_anyframe(s: str) -> Optional[Any]:
    if not s:
        return None
    i = s.find("[")
    j = s.find("{")
    if i == -1 and j == -1:
        return None
    start = min([x for x in (i, j) if x != -1])
    end = max(s.rfind("]"), s.rfind("}"))
    if end == -1 or end <= start:
        return None
    raw = s[start:end + 1]
    try:
        return json.loads(raw)
    except Exception:
        return None


def _extract_socketio_event_name_if_placeholder(s: str) -> Optional[str]:
    if not s or '"_placeholder"' not in s:
        return None
    k = s.find('["')
    if k == -1:
        return None
    k += 2
    m = s.find('"', k)
    if m == -1:
        return None
    return s[k:m]


def _maybe_ingest_assets(event_name: Optional[str], payload: Any) -> None:
    if event_name != "updateAssets":
        return
    if not isinstance(payload, list):
        return
    for it in payload:
        if not (isinstance(it, list) and len(it) >= 2):
            continue
        try:
            aid = int(it[0])
        except Exception:
            continue
        cand = it[1] if isinstance(it[1], str) else None
        if not cand and len(it) >= 3 and isinstance(it[2], str):
            cand = it[2]
        if cand:
            _ASSET_ID_TO_SYMBOL[aid] = cand

    STATE.tick_feed.asset_map_size = len(_ASSET_ID_TO_SYMBOL)

    target_norm = _norm(STATE.symbol)
    if STATE.tick_feed.asset_id_for_symbol is None:
        for aid, name in _ASSET_ID_TO_SYMBOL.items():
            if _norm(name) == target_norm or target_norm in _norm(name):
                STATE.tick_feed.asset_id_for_symbol = aid
                break


def _sanitize_preview(s: str) -> str:
    if not s:
        return s
    if '["auth"' in s or '["user_init"' in s:
        return "(redacted auth frame)"
    return s


def _feed_frame_preview(preview: str, kind: str) -> None:
    tf = STATE.tick_feed
    tf.frames_seen += 1
    tf.frames_last_ts = time.time()
    tail = tf.frames_tail or []
    tail.append({"ts": tf.frames_last_ts, "kind": kind, "preview": _sanitize_preview(preview)[:160]})
    if len(tail) > 10:
        tail = tail[-10:]
    tf.frames_tail = tail


def _try_pick_tick_triplet(it: Any) -> Optional[Tuple[str, float, float]]:
    if not (isinstance(it, list) and len(it) >= 3):
        return None
    sym = it[0]
    try:
        ts = float(it[1])
        price = float(it[2])
        if ts < 1_000_000_000:
            return None
    except Exception:
        return None

    if isinstance(sym, (int, float)):
        name = _ASSET_ID_TO_SYMBOL.get(int(sym))
        sym_str = name if name else str(int(sym))
    else:
        sym_str = str(sym)

    return (sym_str, ts, price)


def _find_ticks_recursive(obj: Any, limit: int = 50) -> List[Tuple[str, float, float]]:
    out: List[Tuple[str, float, float]] = []

    def walk(x: Any):
        nonlocal out
        if len(out) >= limit:
            return
        if isinstance(x, list):
            t = _try_pick_tick_triplet(x)
            if t:
                out.append(t)
                return
            for y in x:
                walk(y)
        elif isinstance(x, dict):
            for v in x.values():
                walk(v)

    walk(obj)
    return out


def _ha_for_series_seeded(closed: List[Dict[str, Any]], seed: Optional[Dict[str, Any]]) -> Dict[int, Dict[str, Any]]:
    out: Dict[int, Dict[str, Any]] = {}
    if not closed:
        return out

    candles = sorted(closed, key=lambda c: int(c.get("timestamp", 0)))

    seed_ts = None
    seed_open = None
    seed_close = None
    if isinstance(seed, dict):
        try:
            seed_ts = int(seed.get("timestamp"))
            seed_open = float(seed.get("ha_open"))
            seed_close = float(seed.get("ha_close"))
        except Exception:
            seed_ts = None
            seed_open = None
            seed_close = None

    # IMPORTANT:
    # If we have a seed, HA must be chained only from that seed forward.
    # Older candles must not influence the chain after restart.
    if seed_ts is not None and seed_open is not None and seed_close is not None:
        trimmed = []
        for c in candles:
            try:
                ts = int(c.get("timestamp", 0))
            except Exception:
                ts = 0
            if ts >= seed_ts:
                trimmed.append(c)
        if trimmed:
            candles = trimmed

    prev_ha_open: Optional[float] = None
    prev_ha_close: Optional[float] = None
    chained_from_seed = False

    if candles and seed_ts is not None and seed_open is not None and seed_close is not None:
        first_ts = int(candles[0].get("timestamp", 0))
        if first_ts > seed_ts:
            prev_ha_open = seed_open
            prev_ha_close = seed_close
            chained_from_seed = True

    for c in candles:
        try:
            ts = int(c["timestamp"])
            o = float(c["open"])
            h = float(c["high"])
            l = float(c["low"])
            cl = float(c["close"])
        except Exception:
            continue

        # exact anchor candle from persisted seed
        if seed_ts is not None and seed_open is not None and seed_close is not None and ts == seed_ts:
            ha_open = float(seed_open)
            ha_close = float(seed_close)
            ha_high = max(h, ha_open, ha_close)
            ha_low = min(l, ha_open, ha_close)
            ha_dir = "UP" if ha_close >= ha_open else "DOWN"
            out[ts] = {
                "ha_open": ha_open,
                "ha_high": ha_high,
                "ha_low": ha_low,
                "ha_close": ha_close,
                "ha_dir": ha_dir,
                "ha_seeded": True,
            }
            prev_ha_open = ha_open
            prev_ha_close = ha_close
            chained_from_seed = True
            continue

        ha_close = (o + h + l + cl) / 4.0

        if prev_ha_open is None or prev_ha_close is None:
            ha_open = (o + cl) / 2.0
            ha_seeded = False
        else:
            ha_open = (prev_ha_open + prev_ha_close) / 2.0
            ha_seeded = chained_from_seed

        ha_high = max(h, ha_open, ha_close)
        ha_low = min(l, ha_open, ha_close)
        ha_dir = "UP" if ha_close >= ha_open else "DOWN"

        out[ts] = {
            "ha_open": ha_open,
            "ha_high": ha_high,
            "ha_low": ha_low,
            "ha_close": ha_close,
            "ha_dir": ha_dir,
            "ha_seeded": ha_seeded,
        }

        prev_ha_open = ha_open
        prev_ha_close = ha_close

    return out
def _merged_closed_for_ha(src: str, tail: int = 500, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
    hist = list(_get_history_closed(symbol))
    stream = list(_get_stream_closed(symbol))

    if "STREAM" in src:
        merged = (hist[-tail:] if hist else []) + (stream[-tail:] if stream else [])
    else:
        merged = (hist[-tail:] if hist else []) or (stream[-tail:] if stream else [])

    by_ts: Dict[int, Dict[str, Any]] = {}
    for c in merged:
        try:
            ts = int(c.get("timestamp", 0))
        except Exception:
            ts = 0
        if ts > 0:
            by_ts[ts] = c  # stream overrides history on same timestamp

    ordered = [by_ts[ts] for ts in sorted(by_ts.keys())]
    if not ordered:
        return ordered

    # Keep only the final contiguous chain spaced by exactly 60 seconds.
    contiguous = [ordered[-1]]
    prev_ts = int(ordered[-1].get("timestamp", 0))

    for c in reversed(ordered[:-1]):
        try:
            ts = int(c.get("timestamp", 0))
        except Exception:
            ts = 0
        if ts > 0 and (prev_ts - ts) == 60:
            contiguous.append(c)
            prev_ts = ts
        else:
            break

    contiguous.reverse()

    if len(contiguous) > tail:
        contiguous = contiguous[-tail:]

    return contiguous
def _attach_ha(candle: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if candle is None:
        return None

    src = str(candle.get("source", "")).upper()
    series = _merged_closed_for_ha(src, tail=500)
    seed = _get_seed_for_symbol(STATE.symbol)
    ha_map = _ha_for_series_seeded(series, seed)
    ts = int(candle.get("timestamp", 0))

    out = dict(candle)
    ha = ha_map.get(ts)
    if ha:
        out.update(ha)
    return out


def _debug_ha_last_payload(candle: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if candle is None:
        return {"ok": False, "error": "no candle"}

    src = str(candle.get("source", "")).upper()
    series = _merged_closed_for_ha(src, tail=500)
    seed = _get_seed_for_symbol(STATE.symbol)
    ha_map = _ha_for_series_seeded(series, seed)

    ts = int(candle.get("timestamp", 0))

    ordered = []
    for c in series:
        try:
            cts = int(c.get("timestamp", 0))
        except Exception:
            cts = 0
        if cts > 0:
            ordered.append((cts, c))
    ordered.sort(key=lambda x: x[0])

    idx = None
    for i, (cts, _) in enumerate(ordered):
        if cts == ts:
            idx = i
            break

    prev_ts = ordered[idx - 1][0] if idx is not None and idx > 0 else None
    prev_candle = ordered[idx - 1][1] if idx is not None and idx > 0 else None

    cur_ha = ha_map.get(ts)
    prev_ha = ha_map.get(prev_ts) if prev_ts is not None else None

    out = {
        "ok": True,
        "symbol": sym,
        "active_mode": STATE.active_mode,
        "source": src,
        "seed": seed,
        "series_len": len(ordered),
        "series_tail_timestamps": [x[0] for x in ordered[-15:]],
        "current_timestamp": ts,
        "current_open_time": candle.get("open_time"),
        "current_close_time": candle.get("close_time"),
        "current_raw": {
            "open": candle.get("open"),
            "high": candle.get("high"),
            "low": candle.get("low"),
            "close": candle.get("close"),
        },
        "current_ha": cur_ha,
        "prev_timestamp": prev_ts,
        "prev_open_time": _fmt(prev_ts) if prev_ts else None,
        "prev_raw": {
            "open": prev_candle.get("open") if prev_candle else None,
            "high": prev_candle.get("high") if prev_candle else None,
            "low": prev_candle.get("low") if prev_candle else None,
            "close": prev_candle.get("close") if prev_candle else None,
        } if prev_candle else None,
        "prev_ha": prev_ha,
    }

    if prev_ha and cur_ha:
        try:
            out["expected_open_from_prev"] = (float(prev_ha["ha_open"]) + float(prev_ha["ha_close"])) / 2.0
        except Exception:
            out["expected_open_from_prev"] = None
    else:
        out["expected_open_from_prev"] = None

    return out

async def _tick_feed_playwright_ws():
    global _TICK_FEED_RUN_ID, _PW_CTX, _PW_PAGE
    _TICK_FEED_RUN_ID += 1
    run_id = _TICK_FEED_RUN_ID

    tf = STATE.tick_feed
    tf.running = True
    tf.last_err = "—"
    tf.ws_seen = 0
    tf.frames_seen = 0
    tf.frames_last_ts = None
    tf.frames_tail = []
    tf.pending_event = None
    tf.pending_ts = None
    tf.asset_id_for_symbol = None
    tf.asset_map_size = 0
    tf.last_tick_event = None
    tf.tick_time_mode = "unknown"
    tf.ticks_seen = 0
    tf.last_price = None
    tf.last_tick_ts_raw = None
    tf.last_tick_ts_used = None
    tf.last_tick_local_ts = None
    tf.last_tick_age_sec = None
    tf.warmup_active = False
    tf.warmup_until_open_ts = None
    tf.warmup_note = "—"

    _ASSET_ID_TO_SYMBOL.clear()
    _SEEN_SYMBOLS.clear()

    ctx = None
    try:
        os.makedirs(PO_PW_PROFILE_DIR, exist_ok=True)
        async with async_playwright() as p:
            browser = p.webkit if PO_PW_BROWSER == "webkit" else p.chromium
            ctx = await browser.launch_persistent_context(
                user_data_dir=PO_PW_PROFILE_DIR,
                headless=PO_PW_HEADLESS,
                args=["--disable-blink-features=AutomationControlled"],
            )
            page = await ctx.new_page()
            _PW_CTX = ctx
            _PW_PAGE = page

            def attach_ws(ws):
                tf.ws_seen += 1
                ws.on("framereceived", lambda payload: _handle_payload(payload, sent=False))
                ws.on("framesent", lambda payload: _handle_payload(payload, sent=True))

            def _handle_payload(payload, sent: bool):
                try:
                    kind = "sent" if sent else "recv"

                    if isinstance(payload, bytes):
                        s = payload.decode("utf-8", errors="ignore")
                        _feed_frame_preview(s, kind + ":bytes")
                        raw_text = s
                        obj = _parse_json_from_anyframe(s)
                    else:
                        s = str(payload)
                        _feed_frame_preview(s, kind + ":str")
                        raw_text = s
                        obj = _parse_json_from_anyframe(s)

                    ev = _extract_socketio_event_name_if_placeholder(raw_text)
                    if ev:
                        tf.pending_event = ev
                        tf.pending_ts = time.time()

                    if obj is None:
                        return

                    paired_event = None
                    paired_payload = obj

                    if isinstance(obj, list) and len(obj) >= 2 and isinstance(obj[0], str):
                        paired_event = obj[0]
                        paired_payload = obj[1]
                    else:
                        if (not sent) and tf.pending_event and tf.pending_ts and (time.time() - tf.pending_ts) <= 2.0:
                            paired_event = tf.pending_event
                            paired_payload = obj
                            tf.pending_event = None
                            tf.pending_ts = None

                    if paired_event:
                        _maybe_ingest_assets(paired_event, paired_payload)

                    ticks = _find_ticks_recursive(paired_payload, limit=50)
                    if not ticks:
                        ticks = _find_ticks_recursive(obj, limit=50)
                    if not ticks:
                        return

                    async def apply():
                        async with _lock:
                            active_norm = _norm(STATE.symbol)
                            for sym_str, t, price in ticks:
                                _SEEN_SYMBOLS.add(sym_str)
                                if _norm(sym_str) == active_norm:
                                    _on_tick_for_symbol(STATE.symbol, t, price, event_name=paired_event)
                                else:
                                    for configured_sym in list(getattr(STATE, "symbols", []) or []):
                                        if _norm(sym_str) == _norm(configured_sym):
                                            _on_tick_for_symbol(configured_sym, t, price, event_name=paired_event)
                                            break
                            _update_hybrid_choice()

                    asyncio.get_event_loop().call_soon_threadsafe(lambda: asyncio.create_task(apply()))

                except Exception as e:
                    tf.last_err = f"{type(e).__name__}: {e}"

            page.on("websocket", attach_ws)
            ctx.on("websocket", attach_ws)

            await page.goto(PO_PW_URL, wait_until="domcontentloaded")
            await asyncio.sleep(2.0)

            try:
                await _pw_switch_symbol_ui(STATE.symbol)
                await asyncio.sleep(2.0)
            except Exception:
                pass

            while not _stop_event.is_set():
                if tf.last_tick_local_ts:
                    tf.last_tick_age_sec = time.time() - tf.last_tick_local_ts
                await asyncio.sleep(0.5)

    except asyncio.CancelledError:
        pass
    except Exception as e:
        if run_id == _TICK_FEED_RUN_ID:
            tf.last_err = f"{type(e).__name__}: {e}"
    finally:
        if run_id == _TICK_FEED_RUN_ID:
            tf.running = False
            _PW_CTX = None
            _PW_PAGE = None
        if ctx is not None:
            try:
                await ctx.close()
            except Exception:
                pass


def _pw_symbol_to_ui_text(symbol: str) -> str:
    s = str(symbol or "").strip()
    low = s.lower()
    otc = low.endswith("_otc")
    if otc:
        s = s[:-4]

    parts = s.split("_")
    if len(parts) == 1 and len(s) == 6 and s.isalpha():
        ui = f"{s[:3]}/{s[3:]}"
    elif len(parts) == 1:
        ui = s.replace("-", "/")
    else:
        ui = "/".join(parts)

    return f"{ui.upper()} OTC" if otc else ui.upper()


async def _pw_switch_symbol_ui(symbol: str) -> Dict[str, Any]:
    page = _PW_PAGE
    if page is None:
        return {"ok": False, "error": "pw_page_not_ready", "symbol": symbol}

    try:
        ui_text = _pw_symbol_to_ui_text(symbol)

        # 1) otevřít menu se symbolem
        await page.locator("a.pair-number-wrap").first.click(timeout=2000)
        await page.wait_for_timeout(700)

        # 2) najít správnou položku v seznamu
        item = page.locator(
            "a.alist__link",
            has=page.locator("span.alist__label", has_text=ui_text)
        ).first

        if await item.count() == 0:
            return {
                "ok": False,
                "error": "symbol_not_found_in_list",
                "symbol": symbol,
                "ui_text": ui_text,
            }

        # 3) kliknout na symbol
        await item.click(timeout=2000)
        await page.wait_for_timeout(1200)

        return {"ok": True, "symbol": symbol, "ui_text": ui_text}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "symbol": symbol}


@app.post("/api/pw/switch_symbol_test")
async def api_pw_switch_symbol_test(symbol: str):
    return await _pw_switch_symbol_ui(symbol)


async def _fetch_history_closed(client: Any, limit: int = 120, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
    fn = getattr(client, "get_candles", None)
    if not callable(fn):
        return []
    sym = symbol or STATE.symbol
    res = fn(sym, TF_SEC, count=limit)
    if inspect.isawaitable(res):
        res = await res
    if not res:
        return []

    candles: List[Dict[str, Any]] = []
    for x in res:
        dt = getattr(x, "timestamp", None)
        if not isinstance(dt, datetime.datetime):
            continue
        ts_open = _align(int(dt.timestamp()) - int(STATE.po_time_offset_sec))
        o, c = _open_close_str(ts_open)
        candles.append({
            "symbol": sym,
            "timestamp": ts_open,
            "open": float(x.open),
            "high": float(x.high),
            "low": float(x.low),
            "close": float(x.close),
            "volume": float(getattr(x, "volume", 0.0)),
            "source": "HISTORY",
            "open_time": o,
            "close_time": c,
        })

    candles.sort(key=lambda cc: int(cc["timestamp"]))
    closed = candles[:-1] if len(candles) >= 2 else []
    for cc in closed:
        cc["age_sec"] = _age_sec(int(cc["timestamp"]))
    return closed[-300:]


async def _restart_tick_feed(reason: str) -> None:
    global _tick_task
    if not PO_USE_PW:
        return

    now = time.time()
    last = STATE.wd_last_restart_ts or 0.0
    if (now - last) < STATE.wd_cooldown_sec:
        return

    STATE.wd_last_restart_ts = now
    STATE.wd_last_reason = reason
    STATE.wd_bad_count = 0

    print(f"[WATCHDOG] restarting tick feed: {reason}")

    old = _tick_task
    _tick_task = None
    if old is not None:
        old.cancel()
        try:
            await asyncio.gather(old, return_exceptions=True)
        except Exception:
            pass

    _tick_task = asyncio.create_task(_tick_feed_playwright_ws())


async def _watchdog_check() -> None:
    if not STATE.wd_enabled:
        return

    tf = STATE.tick_feed
    now = time.time()

    # compute age
    age = tf.last_tick_age_sec
    running = tf.running

    bad = False
    reason = "ok"

    if not running:
        bad = True
        reason = "tick_feed_not_running"
    elif age is None:
        # no ticks yet -> ignore during grace period after engine start
        start_ts = STATE.wd_engine_start_ts or now
        if (now - start_ts) < STATE.wd_start_grace_sec:
            bad = False
            reason = "grace_no_ticks_yet"
        else:
            bad = True
            reason = "no_ticks_yet"
    elif age > STATE.wd_tick_max_age_sec:
        bad = True
        reason = f"tick_stale_age={age:.1f}s"

    if bad:
        STATE.wd_bad_count += 1
        if STATE.wd_bad_count >= STATE.wd_fails_required:
            await _restart_tick_feed(reason)
    else:
        STATE.wd_bad_count = 0
        STATE.wd_last_reason = reason


async def _engine_loop():
    global _tick_task

    STATE.last_connect_error = "—"
    STATE.last_candles_error = "—"
    STATE.last_fetch_count = 0
    STATE.last_poll_ts = None

    STATE.stream_current = None
    STATE.stream_closed = []
    STATE.stream = StreamStats()
    STATE.active_mode = "HISTORY"
    STATE.history_age_sec = None
    STATE.stream_age_sec = None
    STATE.tick_feed = TickFeedStats(frames_tail=[])

    STATE.wd_bad_count = 0
    STATE.wd_last_restart_ts = None
    STATE.wd_last_reason = "—"
    STATE.wd_engine_start_ts = time.time()

    ssid = _read_ssid()
    if not ssid:
        STATE.connected = False
        STATE.last_connect_error = "Missing SSID"
        return

    try:
        client = AsyncPocketOptionClient(ssid=ssid, is_demo=STATE.is_demo, enable_logging=False)
        await client.connect()
        STATE.connected = True
    except Exception as e:
        STATE.connected = False
        STATE.last_connect_error = f"{type(e).__name__}: {e}"
        return

    if PO_USE_PW:
        _tick_task = asyncio.create_task(_tick_feed_playwright_ws())
    else:
        _tick_task = None

    last_hist = 0.0

    while not _stop_event.is_set():
        now = time.time()
        STATE.last_poll_ts = now

        try:
            await _watchdog_check()
        except Exception:
            pass

        if (now - last_hist) >= 2.0:
            last_hist = now
            total_fetch_count = 0
            last_active_hist_closed = None
            symbol_errors = []

            for sym in list(getattr(STATE, "symbols", []) or [STATE.symbol]):
                try:
                    hist_closed = await _fetch_history_closed(
                        client,
                        limit=_history_limit_from_seed(default=120, maximum=1500),
                        symbol=sym,
                    )
                    ss = _get_symbol_state(sym)
                    ss.history_closed = hist_closed
                    total_fetch_count += len(hist_closed)
                    if sym == STATE.symbol:
                        last_active_hist_closed = hist_closed
                except Exception as e:
                    symbol_errors.append(f"{sym}:{type(e).__name__}:{e}")

            async with _lock:
                if last_active_hist_closed is not None:
                    STATE.history_closed = last_active_hist_closed
                STATE.last_fetch_count = total_fetch_count
                _update_hybrid_choice()

            STATE.last_candles_error = "—" if not symbol_errors else " | ".join(symbol_errors[:5])

        await asyncio.sleep(1.0)

    if _tick_task:
        _tick_task.cancel()
        try:
            await asyncio.gather(_tick_task, return_exceptions=True)
        except Exception:
            pass

    STATE.connected = False


@app.get("/api/start")
async def api_start():
    global _engine_task
    if STATE.running and _engine_task and not _engine_task.done():
        return {"ok": True, "msg": "already running"}
    _stop_event.clear()
    STATE.running = True
    _engine_task = asyncio.create_task(_engine_loop())
    return {"ok": True, "msg": "started"}


@app.post("/api/stop")
async def api_stop():
    global _engine_task
    if not STATE.running:
        return {"ok": True, "msg": "already stopped"}
    _stop_event.set()
    STATE.running = False
    if _engine_task:
        try:
            await asyncio.wait_for(_engine_task, timeout=8.0)
        except Exception:
            pass
    return {"ok": True, "msg": "stopped"}


@app.post("/api/ha_seed")
def api_ha_seed(payload: Dict[str, Any] = Body(...)):
    try:
        ha_open = float(payload["ha_open"])
        ha_close = float(payload["ha_close"])
    except Exception:
        return {"ok": False, "error": "Missing/invalid ha_open or ha_close"}

    ts = payload.get("timestamp", None)
    if ts is None:
        last = _active_last_closed()
        if not last:
            return {"ok": False, "error": "No last closed candle available to seed"}
        ts = int(last.get("timestamp"))
    else:
        try:
            ts = int(ts)
        except Exception:
            return {"ok": False, "error": "Invalid timestamp"}

    sym = STATE.symbol
    _HA_SEEDS[sym] = {"timestamp": ts, "ha_open": ha_open, "ha_close": ha_close, "updated_at": time.time()}
    _save_ha_seeds()
    return {"ok": True, "symbol": sym, "saved": _HA_SEEDS[sym]}


@app.get("/api/tick_status")
def api_tick_status():
    tf = STATE.tick_feed
    sym = STATE.symbol
    return {
        "ok": True,
        "symbol": sym,
        "tick_feed": {
            "browser": tf.browser,
            "running": tf.running,
            "last_err": tf.last_err,
            "ws_seen": tf.ws_seen,
            "frames_seen": tf.frames_seen,
            "ticks_seen": tf.ticks_seen,
            "last_price": tf.last_price,
            "last_tick_age_sec": tf.last_tick_age_sec,
            "last_tick_event": tf.last_tick_event,
            "tick_time_mode": tf.tick_time_mode,
            "warmup_active": tf.warmup_active,
            "warmup_note": tf.warmup_note,
            "asset_id_for_symbol": tf.asset_id_for_symbol,
            "asset_map_size": tf.asset_map_size,
            "ha_seed_for_symbol": _get_seed_for_symbol(STATE.symbol),
            "pending_event": tf.pending_event,
            "frames_tail": tf.frames_tail,
        },
        "stream_ticks_seen": STATE.stream.ticks_seen,
        "stream_closed_len": len(STATE.stream_closed or []),
        "active_mode": STATE.active_mode,
        "watchdog": {
            "enabled": STATE.wd_enabled,
            "tick_max_age_sec": STATE.wd_tick_max_age_sec,
            "fails_required": STATE.wd_fails_required,
            "cooldown_sec": STATE.wd_cooldown_sec,
            "start_grace_sec": STATE.wd_start_grace_sec,
            "bad_count": STATE.wd_bad_count,
            "last_restart_ts": STATE.wd_last_restart_ts,
            "last_reason": STATE.wd_last_reason,
        },
    }


@app.get("/api/last")
def api_last(closed: int = 0):
    if closed == 1:
        c = _attach_ha(_active_last_closed())
        return {"ok": True, "closed": True, "candle": c, "active_mode": STATE.active_mode}
    current_stream = _get_stream_current()
    if STATE.active_mode == "STREAM" and current_stream is not None:
        c = _attach_ha(current_stream)
        return {"ok": True, "closed": False, "candle": c, "active_mode": STATE.active_mode}
    c = _attach_ha(_active_last_closed())
    return {"ok": True, "closed": True, "candle": c, "active_mode": STATE.active_mode}


@app.get("/api/debug_ha_last")
def api_debug_ha_last():
    c = _active_last_closed()
    return _debug_ha_last_payload(c)


@app.get("/")
def root():
    return {"app": APP_NAME, "symbol": STATE.symbol, "watchdog": {"enabled": WD_ENABLED, "start_grace_sec": WD_START_GRACE_SEC}}


@app.get("/api/symbols")
def api_symbols():
    return {
        "ok": True,
        "active_symbol": STATE.symbol,
        "symbols": list(getattr(STATE, "symbols", []) or []),
        "by_symbol_keys": list((getattr(STATE, "by_symbol", {}) or {}).keys()),
    }


@app.get("/api/symbols/debug_all")
def api_symbols_debug_all():
    out = []
    by_symbol = getattr(STATE, "by_symbol", {}) or {}
    for sym in list(getattr(STATE, "symbols", []) or []):
        ss = by_symbol.get(sym)
        out.append({
            "symbol": sym,
            "is_active": sym == STATE.symbol,
            "exists": ss is not None,
            "history_closed_len": len(getattr(ss, "history_closed", []) or []) if ss else 0,
            "stream_closed_len": len(getattr(ss, "stream_closed", []) or []) if ss else 0,
            "has_stream_current": bool(getattr(ss, "stream_current", None)) if ss else False,
            "active_mode": getattr(ss, "active_mode", None) if ss else None,
        })
    return {
        "ok": True,
        "active_symbol": STATE.symbol,
        "items": out,
    }


@app.get("/api/strategy/debug_all_symbols")
def api_strategy_debug_all_symbols():
    old_symbol = STATE.symbol
    items = []
    try:
        for sym in list(getattr(STATE, "symbols", []) or []):
            STATE.symbol = sym
            data = _strategy_v1__build_debug()
            items.append({
                "symbol": sym,
                "is_active": sym == old_symbol,
                "active_mode": data.get("active_mode"),
                "state": data.get("state"),
                "trend_buy": data.get("trend_buy"),
                "trend_sell": data.get("trend_sell"),
                "chaos": data.get("chaos"),
                "prepare_buy": data.get("prepare_buy"),
                "prepare_sell": data.get("prepare_sell"),
                "final_buy": data.get("final_buy"),
                "final_sell": data.get("final_sell"),
            })
        return {
            "ok": True,
            "active_symbol": old_symbol,
            "items": items,
        }
    finally:
        STATE.symbol = old_symbol


@app.get("/api/strategy/signals_scan")
def api_strategy_signals_scan():
    old_symbol = STATE.symbol
    items = []
    try:
        for sym in list(getattr(STATE, "symbols", []) or []):
            STATE.symbol = sym
            data = _strategy_v1__build_debug()
            state = data.get("state")
            if data.get("final_buy") or data.get("final_sell") or data.get("prepare_buy") or data.get("prepare_sell") or not data.get("chaos"):
                items.append({
                    "symbol": sym,
                    "state": state,
                    "prepare_buy": data.get("prepare_buy"),
                    "prepare_sell": data.get("prepare_sell"),
                    "final_buy": data.get("final_buy"),
                    "final_sell": data.get("final_sell"),
                    "trend_buy": data.get("trend_buy"),
                    "trend_sell": data.get("trend_sell"),
                    "chaos": data.get("chaos"),
                })
        return {
            "ok": True,
            "active_symbol": old_symbol,
            "count": len(items),
            "items": items,
        }
    finally:
        STATE.symbol = old_symbol


def _strategy_v1__candidate_rank(data):
    state = data.get("state") or ""
    if state.startswith("FINAL_"):
        return 100
    if state.startswith("PREPARE_"):
        return 90
    if state in ("BUY_WAITING_REACTION", "SELL_WAITING_REACTION"):
        return 80
    if state in ("BUY_WAITING_NEW_CANDLE", "SELL_WAITING_NEW_CANDLE"):
        return 70
    if state in ("BUY_TREND_NO_CROSSES", "SELL_TREND_NO_CROSSES"):
        return 60
    if not data.get("chaos"):
        return 50
    return 0


def _strategy_v1__pick_best_symbol_candidate():
    old_symbol = STATE.symbol
    best = None

    try:
        for sym in list(getattr(STATE, "symbols", []) or []):
            STATE.symbol = sym
            data = _strategy_v1__build_debug()
            rank = _strategy_v1__candidate_rank(data)

            row = {
                "symbol": sym,
                "rank": rank,
                "state": data.get("state"),
                "trend_buy": data.get("trend_buy"),
                "trend_sell": data.get("trend_sell"),
                "chaos": data.get("chaos"),
                "prepare_buy": data.get("prepare_buy"),
                "prepare_sell": data.get("prepare_sell"),
                "final_buy": data.get("final_buy"),
                "final_sell": data.get("final_sell"),
            }

            if best is None or row["rank"] > best["rank"]:
                best = row

        return best
    finally:
        STATE.symbol = old_symbol


@app.get("/api/strategy/best_symbol_candidate")
def api_strategy_best_symbol_candidate():
    best = _strategy_v1__pick_best_symbol_candidate()
    return {
        "ok": True,
        "active_symbol": STATE.symbol,
        "best": best,
        "would_switch": bool(best and best.get("symbol") and best.get("symbol") != STATE.symbol and int(best.get("rank") or 0) > 0),
    }


@app.post("/api/symbols/switch")
async def api_symbols_switch(symbol: str):
    global _tick_task

    symbols = list(getattr(STATE, "symbols", []) or [])
    if symbol not in symbols:
        return {
            "ok": False,
            "error": "invalid_symbol",
            "requested_symbol": symbol,
            "allowed_symbols": symbols,
        }

    old_symbol = STATE.symbol
    STATE.symbol = symbol

    ss = _get_symbol_state(symbol)
    ss.stream_current = None
    ss.stream_closed = []
    ss.stream_age_sec = None
    ss.active_mode = "HISTORY"

    STATE.stream_current = None
    STATE.stream_closed = []
    STATE.stream_age_sec = None
    STATE.active_mode = "HISTORY"

    tf = STATE.tick_feed
    tf.last_tick_event = None
    tf.last_tick_ts_raw = None
    tf.last_tick_ts_used = None
    tf.last_tick_local_ts = None
    tf.last_tick_age_sec = None
    tf.last_price = None
    tf.warmup_active = False
    tf.warmup_until_open_ts = None
    tf.warmup_note = "switch_reset"
    tf.asset_id_for_symbol = None
    tf.pending_event = None
    tf.frames_tail = []

    if _tick_task is not None:
        _tick_task.cancel()
        try:
            await asyncio.gather(_tick_task, return_exceptions=True)
        except Exception:
            pass
        _tick_task = None

    if PO_USE_PW:
        _tick_task = asyncio.create_task(_tick_feed_playwright_ws())
        await asyncio.sleep(4.0)

    ui_switch_result = None
    if PO_USE_PW:
        try:
            ui_switch_result = await _pw_switch_symbol_ui(symbol)
        except Exception as e:
            ui_switch_result = {"ok": False, "error": f"{type(e).__name__}: {e}", "symbol": symbol}

    try:
        _update_hybrid_choice()
    except Exception:
        pass

    return {
        "ok": True,
        "old_symbol": old_symbol,
        "active_symbol": STATE.symbol,
        "tick_feed_restarted": bool(PO_USE_PW),
        "ui_switch_result": ui_switch_result,
    }


@app.get("/api/assets/search")
def api_assets_search(q: str = ""):
    qn = (q or "").strip().lower()
    items = []
    for aid, name in sorted((_ASSET_ID_TO_SYMBOL or {}).items(), key=lambda x: str(x[1])):
        text = str(name)
        if not qn or qn in text.lower():
            items.append({"asset_id": aid, "symbol": text})
    return {"ok": True, "query": q, "count": len(items), "items": items[:200]}


@app.get("/api/symbols/history_one")
async def api_symbols_history_one(symbol: str, limit: int = 20):
    ssid = _read_ssid()
    if not ssid:
        return {"ok": False, "error": "Missing SSID", "symbol": symbol}

    try:
        client = AsyncPocketOptionClient(ssid=ssid, is_demo=STATE.is_demo, enable_logging=False)
        await client.connect()
        items = await _fetch_history_closed(client, limit=limit, symbol=symbol)
        return {
            "ok": True,
            "symbol": symbol,
            "count": len(items),
            "first_open_time": items[0]["open_time"] if items else None,
            "last_open_time": items[-1]["open_time"] if items else None,
        }
    except Exception as e:
        return {
            "ok": False,
            "symbol": symbol,
            "error": f"{type(e).__name__}: {e}",
        }
    finally:
        try:
            await client.close()
        except Exception:
            pass


def _last_n__item_to_dict(item):
    if isinstance(item, dict):
        return item

    if hasattr(item, "model_dump"):
        try:
            return item.model_dump()
        except Exception:
            pass

    if hasattr(item, "dict"):
        try:
            return item.dict()
        except Exception:
            pass

    data = {}
    for key in (
        "symbol",
        "timestamp",
        "open",
        "high",
        "low",
        "close",
        "volume",
        "source",
        "open_time",
        "close_time",
        "age_sec",
        "ha_open",
        "ha_high",
        "ha_low",
        "ha_close",
        "ha_dir",
        "ha_seeded",
    ):
        if hasattr(item, key):
            try:
                data[key] = getattr(item, key)
            except Exception:
                pass

    if data:
        return data

    return {"value": str(item)}


def _last_n__looks_like_candle(item):
    d = _last_n__item_to_dict(item)
    return isinstance(d, dict) and all(k in d for k in ("timestamp", "open", "high", "low", "close"))


def _last_n__to_list(obj):
    if isinstance(obj, (list, tuple)):
        return list(obj)

    if type(obj).__name__ == "deque":
        try:
            return list(obj)
        except Exception:
            return []

    return []


def _last_n__pick_store(closed=1):
    preferred_closed = [
        "stream_closed",
        "stream_closed_candles",
        "candles_closed",
        "closed_candles",
        "closed_bars",
        "bars_closed",
        "minute_closed",
        "stream_history",
    ]

    preferred_all = [
        "stream_candles",
        "candles_all",
        "all_candles",
        "candles",
        "bars",
        "stream_live",
        "live_candles",
        "minute_candles",
        "stream_history",
        "stream_closed",
        "candles_closed",
        "closed_candles",
    ]

    names = preferred_closed if int(closed) == 1 else preferred_all

    for name in names:
        if name in globals():
            seq = _last_n__to_list(globals()[name])
            if seq and _last_n__looks_like_candle(seq[-1]):
                return name, seq

    candidates = []
    for name, obj in globals().items():
        if name.startswith("_"):
            continue

        seq = _last_n__to_list(obj)
        if not seq:
            continue

        try:
            sample = seq[-1]
        except Exception:
            continue

        if not _last_n__looks_like_candle(sample):
            continue

        lname = name.lower()
        score = 0

        if "candle" in lname:
            score += 20
        if "bar" in lname:
            score += 10
        if "stream" in lname:
            score += 12
        if "history" in lname or "buffer" in lname:
            score += 8

        if int(closed) == 1:
            if "closed" in lname:
                score += 50
            if "live" in lname or "open" in lname or "current" in lname:
                score -= 30
        else:
            if "live" in lname or "open" in lname or "current" in lname or "all" in lname:
                score += 30
            if "closed" in lname:
                score += 5

        score += min(len(seq), 500) / 1000.0
        candidates.append((score, name, seq))

    if not candidates:
        return None, []

    candidates.sort(key=lambda x: x[0], reverse=True)
    _, name, seq = candidates[0]
    return name, seq




@app.get("/api/last_n")
def api_last_n(
    n: int = Query(50, ge=1, le=500),
    closed: int = Query(1)
):
    def _to_dict(x):
        if isinstance(x, dict):
            return dict(x)
        if hasattr(x, "model_dump"):
            try:
                return dict(x.model_dump())
            except Exception:
                pass
        if hasattr(x, "dict"):
            try:
                return dict(x.dict())
            except Exception:
                pass
        return {"value": str(x)}

    def _calc_ha(items):
        out = []
        prev_ha_open = None
        prev_ha_close = None

        for raw in items:
            c = _to_dict(raw)

            if not all(k in c for k in ("open", "high", "low", "close")):
                out.append(c)
                continue

            o = float(c["open"])
            h = float(c["high"])
            l = float(c["low"])
            cl = float(c["close"])

            ha_close = (o + h + l + cl) / 4.0

            if prev_ha_open is None or prev_ha_close is None:
                ha_open = (o + cl) / 2.0
            else:
                ha_open = (prev_ha_open + prev_ha_close) / 2.0

            ha_high = max(h, ha_open, ha_close)
            ha_low = min(l, ha_open, ha_close)
            ha_dir = "UP" if ha_close >= ha_open else "DOWN"

            c["ha_open"] = ha_open
            c["ha_high"] = ha_high
            c["ha_low"] = ha_low
            c["ha_close"] = ha_close
            c["ha_dir"] = ha_dir
            c["ha_seeded"] = True

            prev_ha_open = ha_open
            prev_ha_close = ha_close
            out.append(c)

        return out

    items = []
    store_name = None

    if int(closed) == 1:
        stream_items = list(getattr(STATE, "stream_closed", []) or [])
        history_items = list(getattr(STATE, "history_closed", []) or [])

        if getattr(STATE, "active_mode", None) == "STREAM":
            if len(stream_items) >= n:
                items = stream_items
                store_name = "STATE.stream_closed"
            elif stream_items and history_items:
                need = max(0, n - len(stream_items))
                hist_part = history_items[-need:] if need > 0 else []
                combined = hist_part + stream_items

                dedup = []
                seen = set()
                for x in combined:
                    ts = None
                    if isinstance(x, dict):
                        ts = x.get("timestamp")
                    if ts in seen:
                        continue
                    seen.add(ts)
                    dedup.append(x)

                items = dedup
                store_name = "STATE.history_closed + STATE.stream_closed"
            elif stream_items:
                items = stream_items
                store_name = "STATE.stream_closed"
            else:
                items = history_items
                store_name = "STATE.history_closed"
        else:
            items = history_items
            store_name = "STATE.history_closed"

        if not items:
            items = history_items
            store_name = "STATE.history_closed"
    else:
        current = getattr(STATE, "stream_current", None)
        closed_items = list(getattr(STATE, "stream_closed", []) or [])

        if current is not None:
            items = closed_items + [current]
            store_name = "STATE.stream_closed + STATE.stream_current"
        else:
            items = closed_items
            store_name = "STATE.stream_closed"

        if not items:
            items = list(getattr(STATE, "history_closed", []) or [])
            store_name = "STATE.history_closed"

    out = _calc_ha(items)[-n:]

    return {
        "ok": True,
        "closed": bool(closed),
        "count": len(out),
        "items": out,
        "store": store_name,
        "active_mode": getattr(STATE, "active_mode", None),
    }



DB_DIR = Path("data")
DB_PATH = DB_DIR / "bot.db"


def _sqlite_connect_v1():
    DB_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def _sqlite_init_v1():
    DB_DIR.mkdir(parents=True, exist_ok=True)

    conn = _sqlite_connect_v1()
    try:
        cur = conn.cursor()

        cur.execute("""
        CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_key TEXT UNIQUE,
            symbol TEXT NOT NULL,
            timeframe TEXT NOT NULL DEFAULT 'M1',
            candle_ts INTEGER NOT NULL,
            signal_time TEXT,
            side TEXT NOT NULL,
            reason TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'new',
            is_informational INTEGER NOT NULL DEFAULT 0,
            expires_at_ts INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_id INTEGER,
            symbol TEXT NOT NULL,
            entry_decision TEXT NOT NULL DEFAULT 'pending',
            result TEXT NOT NULL DEFAULT '',
            entered_at TEXT,
            closed_at TEXT,
            note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(signal_id) REFERENCES signals(id)
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS app_state (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """)

        cur.execute("CREATE INDEX IF NOT EXISTS idx_signals_symbol_ts ON signals(symbol, candle_ts)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_signals_status ON signals(status)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_trades_signal_id ON trades(signal_id)")

        conn.commit()
    finally:
        conn.close()


@app.on_event("startup")
def _sqlite_startup_init_v1():
    _sqlite_init_v1()


@app.get("/api/db_status")
def api_db_status():
    DB_DIR.mkdir(parents=True, exist_ok=True)
    exists = DB_PATH.exists()
    size = DB_PATH.stat().st_size if exists else 0

    tables = []
    if exists:
        conn = _sqlite_connect_v1()
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT name
                FROM sqlite_master
                WHERE type='table'
                ORDER BY name
            """)
            tables = [row[0] for row in cur.fetchall()]
        finally:
            conn.close()

    return {
        "ok": True,
        "db_path": str(DB_PATH),
        "exists": exists,
        "size": size,
        "tables": tables,
    }


def _db_execute(sql, params=()):
    conn = _sqlite_connect_v1()
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def _db_fetchall(sql, params=()):
    conn = _sqlite_connect_v1()
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        rows = cur.fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


def _db_fetchone(sql, params=()):
    conn = _sqlite_connect_v1()
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        row = cur.fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def _make_signal_key(symbol, candle_ts, side):
    return f"{symbol}:{candle_ts}:{side}"


@app.post("/api/signals/create_test")
def api_signals_create_test():
    last = None

    try:
        if getattr(STATE, "stream_closed", None):
            if len(STATE.stream_closed) > 0:
                last = STATE.stream_closed[-1]
    except Exception:
        last = None

    if not last:
        try:
            if getattr(STATE, "history_closed", None):
                if len(STATE.history_closed) > 0:
                    last = STATE.history_closed[-1]
        except Exception:
            last = None

    if not last:
        return {
            "ok": False,
            "error": "no_closed_candle_available"
        }

    symbol = last.get("symbol") or getattr(STATE, "symbol", "UNKNOWN")
    candle_ts = int(last.get("timestamp"))
    side = "BUY" if (last.get("ha_dir") == "UP") else "SELL"
    reason = "TEST_SIGNAL"
    signal_key = _make_signal_key(symbol, candle_ts, side)
    expires_at_ts = candle_ts + 60

    existing = _db_fetchone(
        "SELECT * FROM signals WHERE signal_key = ?",
        (signal_key,)
    )
    if existing:
        return {
            "ok": True,
            "created": False,
            "signal": existing
        }

    signal_id = _db_execute(
        """
        INSERT INTO signals (
            signal_key,
            symbol,
            timeframe,
            candle_ts,
            signal_time,
            side,
            reason,
            status,
            is_informational,
            expires_at_ts
        )
        VALUES (?, ?, 'M1', ?, datetime('now'), ?, ?, 'new', 0, ?)
        """,
        (
            signal_key,
            symbol,
            candle_ts,
            side,
            reason,
            expires_at_ts
        )
    )

    row = _db_fetchone(
        "SELECT * FROM signals WHERE id = ?",
        (signal_id,)
    )

    return {
        "ok": True,
        "created": True,
        "signal": row
    }


@app.get("/api/signals")
def api_signals(limit: int = Query(20, ge=1, le=200)):
    rows = _db_fetchall(
        """
        SELECT *
        FROM signals
        ORDER BY id DESC
        LIMIT ?
        """,
        (limit,)
    )
    return {
        "ok": True,
        "count": len(rows),
        "items": rows
    }


@app.get("/api/signals/last")
def api_signals_last():
    row = _db_fetchone(
        """
        SELECT *
        FROM signals
        ORDER BY id DESC
        LIMIT 1
        """
    )
    return {
        "ok": True,
        "item": row
    }


def _db_execute_update(sql, params=()):
    conn = _sqlite_connect_v1()
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        conn.commit()
        return cur.rowcount
    finally:
        conn.close()


def _get_signal_by_id(signal_id: int):
    return _db_fetchone(
        "SELECT * FROM signals WHERE id = ?",
        (signal_id,)
    )


def _get_trade_by_signal_id(signal_id: int):
    return _db_fetchone(
        "SELECT * FROM trades WHERE signal_id = ? ORDER BY id DESC LIMIT 1",
        (signal_id,)
    )


def _upsert_trade_decision(signal_row, decision: str):
    signal_id = int(signal_row["id"])
    symbol = signal_row["symbol"]

    existing_trade = _get_trade_by_signal_id(signal_id)

    if existing_trade:
        _db_execute_update(
            """
            UPDATE trades
            SET entry_decision = ?,
                entered_at = CASE
                    WHEN ? = 'taken' THEN datetime('now')
                    ELSE entered_at
                END,
                updated_at = CURRENT_TIMESTAMP
            WHERE signal_id = ?
            """,
            (decision, decision, signal_id)
        )
    else:
        _db_execute(
            """
            INSERT INTO trades (
                signal_id,
                symbol,
                entry_decision,
                result,
                entered_at,
                created_at,
                updated_at
            )
            VALUES (
                ?, ?, ?, '',
                CASE WHEN ? = 'taken' THEN datetime('now') ELSE NULL END,
                CURRENT_TIMESTAMP,
                CURRENT_TIMESTAMP
            )
            """,
            (signal_id, symbol, decision, decision)
        )

    return _get_trade_by_signal_id(signal_id)


@app.post("/api/signals/{signal_id}/take")
def api_signal_take(signal_id: int):
    signal_row = _get_signal_by_id(signal_id)
    if not signal_row:
        return {
            "ok": False,
            "error": "signal_not_found",
            "signal_id": signal_id
        }

    _db_execute_update(
        """
        UPDATE signals
        SET status = 'taken',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (signal_id,)
    )

    signal_row = _get_signal_by_id(signal_id)
    trade_row = _upsert_trade_decision(signal_row, "taken")

    return {
        "ok": True,
        "action": "take",
        "signal": signal_row,
        "trade": trade_row
    }


@app.post("/api/signals/{signal_id}/skip")
def api_signal_skip(signal_id: int):
    signal_row = _get_signal_by_id(signal_id)
    if not signal_row:
        return {
            "ok": False,
            "error": "signal_not_found",
            "signal_id": signal_id
        }

    _db_execute_update(
        """
        UPDATE signals
        SET status = 'skipped',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (signal_id,)
    )

    signal_row = _get_signal_by_id(signal_id)
    trade_row = _upsert_trade_decision(signal_row, "skipped")

    return {
        "ok": True,
        "action": "skip",
        "signal": signal_row,
        "trade": trade_row
    }


@app.get("/api/trades")
def api_trades(limit: int = Query(20, ge=1, le=200)):
    rows = _db_fetchall(
        """
        SELECT *
        FROM trades
        ORDER BY id DESC
        LIMIT ?
        """,
        (limit,)
    )
    return {
        "ok": True,
        "count": len(rows),
        "items": rows
    }


def _set_trade_result(signal_id: int, result_value: str):
    trade_row = _get_trade_by_signal_id(signal_id)

    if trade_row:
        _db_execute_update(
            """
            UPDATE trades
            SET result = ?,
                closed_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP
            WHERE signal_id = ?
            """,
            (result_value, signal_id)
        )
    else:
        signal_row = _get_signal_by_id(signal_id)
        if not signal_row:
            return None

        _db_execute(
            """
            INSERT INTO trades (
                signal_id,
                symbol,
                entry_decision,
                result,
                entered_at,
                closed_at,
                created_at,
                updated_at
            )
            VALUES (
                ?, ?, 'taken', ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
                CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
            )
            """,
            (signal_id, signal_row["symbol"], result_value)
        )

    return _get_trade_by_signal_id(signal_id)


@app.post("/api/signals/{signal_id}/win")
def api_signal_win(signal_id: int):
    signal_row = _get_signal_by_id(signal_id)
    if not signal_row:
        return {
            "ok": False,
            "error": "signal_not_found",
            "signal_id": signal_id
        }

    _db_execute_update(
        """
        UPDATE signals
        SET status = 'win',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (signal_id,)
    )

    signal_row = _get_signal_by_id(signal_id)
    trade_row = _set_trade_result(signal_id, "WIN")

    return {
        "ok": True,
        "action": "win",
        "signal": signal_row,
        "trade": trade_row
    }


@app.post("/api/signals/{signal_id}/loss")
def api_signal_loss(signal_id: int):
    signal_row = _get_signal_by_id(signal_id)
    if not signal_row:
        return {
            "ok": False,
            "error": "signal_not_found",
            "signal_id": signal_id
        }

    _db_execute_update(
        """
        UPDATE signals
        SET status = 'loss',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (signal_id,)
    )

    signal_row = _get_signal_by_id(signal_id)
    trade_row = _set_trade_result(signal_id, "LOSS")

    return {
        "ok": True,
        "action": "loss",
        "signal": signal_row,
        "trade": trade_row
    }


@app.get("/api/stats")
def api_stats():
    signals_total_row = _db_fetchone("SELECT COUNT(*) AS n FROM signals")
    trades_total_row = _db_fetchone("SELECT COUNT(*) AS n FROM trades")

    by_status_rows = _db_fetchall(
        """
        SELECT status, COUNT(*) AS n
        FROM signals
        GROUP BY status
        ORDER BY status
        """
    )

    trade_result_rows = _db_fetchall(
        """
        SELECT result, COUNT(*) AS n
        FROM trades
        GROUP BY result
        ORDER BY result
        """
    )

    signals_total = int((signals_total_row or {}).get("n", 0) or 0)
    trades_total = int((trades_total_row or {}).get("n", 0) or 0)

    status_map = {
        "new": 0,
        "taken": 0,
        "skipped": 0,
        "win": 0,
        "loss": 0,
    }

    for row in by_status_rows:
        key = row.get("status")
        val = int(row.get("n", 0) or 0)
        status_map[key] = val

    result_map = {
        "WIN": 0,
        "LOSS": 0,
        "": 0,
    }

    for row in trade_result_rows:
        key = row.get("result")
        val = int(row.get("n", 0) or 0)
        result_map[key] = val

    wins = int(result_map.get("WIN", 0) or 0)
    losses = int(result_map.get("LOSS", 0) or 0)
    decided = wins + losses
    winrate = round((wins / decided) * 100.0, 2) if decided > 0 else 0.0

    return {
        "ok": True,
        "signals_total": signals_total,
        "trades_total": trades_total,
        "signals": status_map,
        "results": {
            "win": wins,
            "loss": losses,
            "decided": decided,
            "winrate": winrate,
        },
    }


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    return """
<!doctype html>
<html lang="cs">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Bot Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #0b1220;
      color: #e5e7eb;
      margin: 0;
      padding: 16px;
    }
    h1, h2, h3 { margin: 0 0 12px 0; }
    .wrap {
      display: grid;
      grid-template-columns: 1fr;
      gap: 16px;
      max-width: 1200px;
      margin: 0 auto;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 16px;
    }
    .card {
      background: #111827;
      border: 1px solid #1f2937;
      border-radius: 14px;
      padding: 16px;
      box-shadow: 0 4px 18px rgba(0,0,0,0.25);
    }
    .muted { color: #9ca3af; }
    .ok { color: #34d399; }
    .bad { color: #f87171; }
    .warn { color: #fbbf24; }
    .mono { font-family: Menlo, Monaco, monospace; }
    .row {
      display: flex;
      justify-content: space-between;
      gap: 10px;
      padding: 6px 0;
      border-bottom: 1px solid #1f2937;
    }
    .row:last-child { border-bottom: none; }
    .buttons {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 12px;
    }
    button {
      background: #2563eb;
      color: white;
      border: none;
      border-radius: 10px;
      padding: 10px 12px;
      cursor: pointer;
      font-weight: 700;
    }
    button:hover { opacity: 0.92; }
    button.gray { background: #4b5563; }
    button.green { background: #059669; }
    button.red { background: #dc2626; }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 14px;
    }
    th, td {
      border-bottom: 1px solid #1f2937;
      padding: 8px 6px;
      text-align: left;
      vertical-align: top;
    }
    th { color: #9ca3af; }
    .pill {
      display: inline-block;
      padding: 3px 8px;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 700;
      background: #1f2937;
    }
    .pill.up { color: #34d399; }
    .pill.down { color: #f87171; }
    .statusline {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      font-size: 14px;
    }
    .small { font-size: 12px; }
    a { color: #93c5fd; text-decoration: none; }
    pre {
      white-space: pre-wrap;
      word-break: break-word;
      background: #0f172a;
      padding: 10px;
      border-radius: 10px;
      overflow: auto;
    }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>PocketOption Bot Dashboard</h1>
      <div class="statusline">
        <div>Symbol: <strong id="symbol">-</strong></div>
        <div>Mode: <strong id="active_mode">-</strong></div>
        <div>Running: <strong id="running">-</strong></div>
        <div>Ticks: <strong id="ticks_seen">-</strong></div>
        <div>Closed candles: <strong id="closed_len">-</strong></div>
        <div>Last price: <strong id="last_price">-</strong></div>
        <div>Last tick age: <strong id="last_tick_age">-</strong></div>
      </div>
      <div class="small muted" style="margin-top:8px;">Auto refresh: 5s</div>
    </div>

    <div class="grid">
      <div class="card">
        <h2>Stats</h2>
        <div id="stats_box" class="mono">loading...</div>
      </div>

      <div class="card">
        <h2>Poslední signál</h2>
        <div id="last_signal_box" class="mono">loading...</div>
        <div class="buttons">
          <button onclick="signalAction('take')">TAKE</button>
          <button class="gray" onclick="signalAction('skip')">SKIP</button>
          <button class="green" onclick="signalAction('win')">WIN</button>
          <button class="red" onclick="signalAction('loss')">LOSS</button>
          <button onclick="createTestSignal()">CREATE TEST</button>
        </div>
        <div id="action_msg" class="small muted" style="margin-top:10px;"></div>
      </div>
    </div>

    <div class="card">
      <h2>4 symboly scan</h2>
      <div id="multi_symbols_wrap">loading...</div>
    </div>

    <div class="card">
      <h2>Posledních 5 signálů</h2>
      <div id="signals_table_wrap">loading...</div>
    </div>

    <div class="card">
      <h2>HA graf</h2>
      <div id="ha_chart_wrap">loading...</div>
    </div>

    <div class="card">
      <h2>Posledních 10 uzavřených svíček</h2>
      <div id="candles_table_wrap">loading...</div>
    </div>
  </div>

<script>
let lastSignalId = null;

async function api(url, opts) {
  const res = await fetch(url, opts || {});
  return await res.json();
}

function esc(v) {
  if (v === null || v === undefined) return "";
  return String(v)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function fmt(v) {
  if (v === null || v === undefined) return "-";
  return String(v);
}

function fmtNum(v, digits = 3) {
  if (v === null || v === undefined || v === "") return "-";
  const n = Number(v);
  if (!Number.isFinite(n)) return esc(v);
  return n.toFixed(digits);
}

function statusText(v) {
  if (v === true) return '<span class="ok">YES</span>';
  if (v === false) return '<span class="bad">NO</span>';
  return esc(v);
}

async function loadStatus() {
  const d = await api("/api/tick_status");
  document.getElementById("symbol").textContent = d.symbol || "-";
  document.getElementById("active_mode").textContent = d.active_mode || "-";
  document.getElementById("running").innerHTML = statusText(d.tick_feed?.running);
  document.getElementById("ticks_seen").textContent = fmt(d.tick_feed?.ticks_seen);
  document.getElementById("closed_len").textContent = fmt(d.stream_closed_len);
  document.getElementById("last_price").textContent = fmt(d.tick_feed?.last_price);
  document.getElementById("last_tick_age").textContent = fmt(d.tick_feed?.last_tick_age_sec);
}

async function loadStats() {
  const d = await api("/api/stats");
  const html = `
    <div class="row"><div>Signals total</div><div><strong>${fmt(d.signals_total)}</strong></div></div>
    <div class="row"><div>Trades total</div><div><strong>${fmt(d.trades_total)}</strong></div></div>
    <div class="row"><div>WIN</div><div><strong>${fmt(d.results?.win)}</strong></div></div>
    <div class="row"><div>LOSS</div><div><strong>${fmt(d.results?.loss)}</strong></div></div>
    <div class="row"><div>Winrate</div><div><strong>${fmt(d.results?.winrate)}%</strong></div></div>
    <div class="row"><div>new</div><div><strong>${fmt(d.signals?.new)}</strong></div></div>
    <div class="row"><div>taken</div><div><strong>${fmt(d.signals?.taken)}</strong></div></div>
    <div class="row"><div>skipped</div><div><strong>${fmt(d.signals?.skipped)}</strong></div></div>
    <div class="row"><div>win</div><div><strong>${fmt(d.signals?.win)}</strong></div></div>
    <div class="row"><div>loss</div><div><strong>${fmt(d.signals?.loss)}</strong></div></div>
  `;
  document.getElementById("stats_box").innerHTML = html;
}

async function loadMultiSymbols() {
  const d = await api("/api/strategy/debug_all_symbols");
  const items = d.items || [];

  if (!items.length) {
    document.getElementById("multi_symbols_wrap").innerHTML = '<div class="muted">Žádná data</div>';
    return;
  }

  const rows = items.map(item => {
    const trend = item.trend_buy ? "BUY" : (item.trend_sell ? "SELL" : "-");
    const active = item.is_active ? '<span class="pill up">ACTIVE LIVE</span>' : '<span class="pill">SCAN</span>';
    const chaos = item.chaos ? '<span class="bad">YES</span>' : '<span class="ok">NO</span>';
    return `
      <tr>
        <td><strong>${esc(item.symbol)}</strong></td>
        <td>${active}</td>
        <td>${esc(item.state)}</td>
        <td>${esc(item.active_mode || "-")}</td>
        <td>${esc(trend)}</td>
        <td>${chaos}</td>
      </tr>
    `;
  }).join("");

  document.getElementById("multi_symbols_wrap").innerHTML = `
    <table>
      <thead>
        <tr>
          <th>Symbol</th>
          <th>Role</th>
          <th>State</th>
          <th>Mode</th>
          <th>Trend</th>
          <th>Chaos</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  `;
}

async function loadLastSignal() {
  const d = await api("/api/signals/last");
  const item = d.item;

  if (!item) {
    lastSignalId = null;
    document.getElementById("last_signal_box").innerHTML = '<div class="muted">Žádný signál</div>';
    return;
  }

  lastSignalId = item.id;
  const sideClass = item.side === "BUY" ? "up" : "down";
  document.getElementById("last_signal_box").innerHTML = `
    <div class="row"><div>ID</div><div><strong>${esc(item.id)}</strong></div></div>
    <div class="row"><div>Symbol</div><div><strong>${esc(item.symbol)}</strong></div></div>
    <div class="row"><div>Side</div><div><span class="pill ${sideClass}">${esc(item.side)}</span></div></div>
    <div class="row"><div>Status</div><div><strong>${esc(item.status)}</strong></div></div>
    <div class="row"><div>Reason</div><div><strong>${esc(item.reason)}</strong></div></div>
    <div class="row"><div>Candle TS</div><div><strong>${esc(item.candle_ts)}</strong></div></div>
    <div class="row"><div>Expires TS</div><div><strong>${esc(item.expires_at_ts)}</strong></div></div>
    <div class="row"><div>Created</div><div><strong>${esc(item.created_at)}</strong></div></div>
  `;
}

async function loadSignals() {
  const d = await api("/api/signals?limit=5");
  const items = d.items || [];

  if (!items.length) {
    document.getElementById("signals_table_wrap").innerHTML = '<div class="muted">Žádné signály</div>';
    return;
  }

  const rows = items.map(item => `
    <tr>
      <td>${esc(item.id)}</td>
      <td>${esc(item.symbol)}</td>
      <td>${esc(item.side)}</td>
      <td>${esc(item.status)}</td>
      <td>${esc(item.reason)}</td>
      <td>${esc(item.candle_ts)}</td>
      <td>${esc(item.created_at)}</td>
    </tr>
  `).join("");

  document.getElementById("signals_table_wrap").innerHTML = `
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Symbol</th>
          <th>Side</th>
          <th>Status</th>
          <th>Reason</th>
          <th>Candle TS</th>
          <th>Created</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  `;
}



function makeHaChart(items) {
  if (!items || !items.length) {
    return '<div class="muted">Žádná data pro HA graf</div>';
  }

  const chartItems = items.slice(-30).filter(x =>
    x &&
    x.ha_open !== undefined &&
    x.ha_high !== undefined &&
    x.ha_low !== undefined &&
    x.ha_close !== undefined
  );

  if (!chartItems.length) {
    return '<div class="muted">HA data nejsou dostupná</div>';
  }

  const width = 1100;
  const height = 320;
  const padL = 16;
  const padR = 16;
  const padT = 16;
  const padB = 24;
  const plotW = width - padL - padR;
  const plotH = height - padT - padB;

  const vals = [];
  for (const x of chartItems) {
    vals.push(Number(x.ha_high), Number(x.ha_low), Number(x.ha_open), Number(x.ha_close));
  }

  let minV = Math.min(...vals);
  let maxV = Math.max(...vals);

  if (!Number.isFinite(minV) || !Number.isFinite(maxV)) {
    return '<div class="muted">Neplatná HA data</div>';
  }

  if (maxV === minV) {
    maxV += 0.001;
    minV -= 0.001;
  }

  const range = maxV - minV;
  const topV = maxV + range * 0.05;
  const botV = minV - range * 0.05;
  const fullRange = topV - botV;

  const y = (v) => {
    const n = (topV - v) / fullRange;
    return padT + n * plotH;
  };

  const step = plotW / chartItems.length;
  const bodyW = Math.max(4, step * 0.55);

  const grid = [];
  for (let i = 0; i < 5; i++) {
    const gy = padT + (plotH / 4) * i;
    grid.push(`<line x1="${padL}" y1="${gy}" x2="${width - padR}" y2="${gy}" stroke="#1f2937" stroke-width="1"/>`);
  }

  const candles = chartItems.map((c, i) => {
    const xCenter = padL + step * i + step / 2;

    const ho = Number(c.ha_open);
    const hh = Number(c.ha_high);
    const hl = Number(c.ha_low);
    const hc = Number(c.ha_close);

    const yo = y(ho);
    const yh = y(hh);
    const yl = y(hl);
    const yc = y(hc);

    const bodyTop = Math.min(yo, yc);
    const bodyBottom = Math.max(yo, yc);
    const bodyHeight = Math.max(2, bodyBottom - bodyTop);

    const isUp = hc >= ho;
    const stroke = isUp ? "#10b981" : "#ef4444";
    const fill = isUp ? "#10b981" : "#ef4444";

    const title = esc(
      `${c.open_time || c.timestamp} | HA O:${fmtNum(ho)} H:${fmtNum(hh)} L:${fmtNum(hl)} C:${fmtNum(hc)}`
    );

    return `
      <g>
        <title>${title}</title>
        <line x1="${xCenter}" y1="${yh}" x2="${xCenter}" y2="${yl}" stroke="${stroke}" stroke-width="2"/>
        <rect x="${xCenter - bodyW / 2}" y="${bodyTop}" width="${bodyW}" height="${bodyHeight}" rx="1" fill="${fill}" stroke="${stroke}" stroke-width="1"/>
      </g>
    `;
  }).join("");

  const labels = `
    <div class="small muted" style="margin-top:8px; display:flex; justify-content:space-between; gap:8px; flex-wrap:wrap;">
      <span>Min: <strong>${fmtNum(minV)}</strong></span>
      <span>Max: <strong>${fmtNum(maxV)}</strong></span>
      <span>Svíček: <strong>${chartItems.length}</strong></span>
      <span>Typ: <strong>Heikin Ashi</strong></span>
    </div>
  `;

  return `
    <div style="overflow:auto;">
      <svg viewBox="0 0 ${width} ${height}" width="100%" height="320" preserveAspectRatio="none" style="background:#0f172a;border-radius:12px;border:1px solid #1f2937;">
        ${grid.join("")}
        ${candles}
      </svg>
    </div>
    ${labels}
  `;
}

async function loadHaChart() {
  const d = await api("/api/last_n?n=30&closed=1");
  const items = d.items || [];
  document.getElementById("ha_chart_wrap").innerHTML = makeHaChart(items);
}


async function loadCandles() {
  const d = await api("/api/last_n?n=10&closed=1");
  const items = d.items || [];

  if (!items.length) {
    document.getElementById("candles_table_wrap").innerHTML = '<div class="muted">Žádné candles</div>';
    return;
  }

  const rows = items.map(item => {
    const haDir = item.ha_dir || "";
    const dirClass = haDir === "UP" ? "up" : (haDir === "DOWN" ? "down" : "");
    return `
      <tr>
        <td>${esc(item.open_time || item.timestamp)}</td>
        <td>${fmtNum(item.open)}</td>
        <td>${fmtNum(item.high)}</td>
        <td>${fmtNum(item.low)}</td>
        <td>${fmtNum(item.close)}</td>
        <td>${fmtNum(item.ha_open)}</td>
        <td>${fmtNum(item.ha_high)}</td>
        <td>${fmtNum(item.ha_low)}</td>
        <td>${fmtNum(item.ha_close)}</td>
        <td><span class="pill ${dirClass}">${esc(haDir || "-")}</span></td>
        <td>${esc(item.source || "-")}</td>
      </tr>
    `;
  }).join("");

  document.getElementById("candles_table_wrap").innerHTML = `
    <table>
      <thead>
        <tr>
          <th>Time</th>
          <th>O</th>
          <th>H</th>
          <th>L</th>
          <th>C</th>
          <th>HA O</th>
          <th>HA H</th>
          <th>HA L</th>
          <th>HA C</th>
          <th>HA Dir</th>
          <th>Src</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  `;
}

async function signalAction(action) {
  const msg = document.getElementById("action_msg");
  if (!lastSignalId) {
    msg.textContent = "Není poslední signál.";
    return;
  }

  msg.textContent = "Provádím " + action + "...";
  try {
    const d = await api(`/api/signals/${lastSignalId}/${action}`, {
      method: "POST"
    });
    msg.textContent = JSON.stringify(d);
    await refreshAll();
  } catch (e) {
    msg.textContent = "Chyba: " + e;
  }
}

async function createTestSignal() {
  const msg = document.getElementById("action_msg");
  msg.textContent = "Vytvářím test signál...";
  try {
    const d = await api("/api/signals/create_test", { method: "POST" });
    msg.textContent = JSON.stringify(d);
    await refreshAll();
  } catch (e) {
    msg.textContent = "Chyba: " + e;
  }
}

async function refreshAll() {
  await Promise.all([
    loadStatus(),
    loadStats(),
    loadMultiSymbols(),
    loadLastSignal(),
    loadSignals(),
    loadHaChart(),
    loadCandles()
  ]);
}

refreshAll();
setInterval(refreshAll, 5000);
</script>
</body>
</html>
"""


def _tg_get_token():
    return (os.getenv("TG_BOT_TOKEN") or "").strip()


def _tg_get_chat_id():
    return (os.getenv("TG_CHAT_ID") or "").strip()


def _tg_is_ready():
    return bool(_tg_get_token() and _tg_get_chat_id())


def _tg_send_message(text_msg: str):
    token = _tg_get_token()
    chat_id = _tg_get_chat_id()

    if not token:
        return {"ok": False, "error": "missing_tg_bot_token"}
    if not chat_id:
        return {"ok": False, "error": "missing_tg_chat_id"}

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = urllib.parse.urlencode({
        "chat_id": chat_id,
        "text": text_msg,
    }).encode("utf-8")

    req = urllib.request.Request(
        url,
        data=payload,
        method="POST",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return {
                "ok": True,
                "status_code": getattr(resp, "status", 200),
                "response_text": raw,
            }
    except Exception as e:
        return {
            "ok": False,
            "error": str(e),
        }


def _tg_build_signal_text(symbol: str, side: str, time_text: str):
    return f"{symbol}\n{side}\n{time_text}"


@app.get("/api/telegram/status")
def api_telegram_status():
    return {
        "ok": True,
        "ready": _tg_is_ready(),
        "has_token": bool(_tg_get_token()),
        "has_chat_id": bool(_tg_get_chat_id()),
    }


@app.post("/api/telegram/test")
def api_telegram_test():
    msg = _tg_build_signal_text(
        symbol=str(getattr(STATE, "symbol", "UNKNOWN")),
        side="BUY",
        time_text=time.strftime("%Y-%m-%d %H:%M:%S"),
    )
    result = _tg_send_message(msg)
    return {
        "ok": result.get("ok", False),
        "message": msg,
        "result": result,
    }


@app.post("/api/telegram/send_last_signal")
def api_telegram_send_last_signal():
    row = _db_fetchone(
        """
        SELECT *
        FROM signals
        ORDER BY id DESC
        LIMIT 1
        """
    )

    if not row:
        return {
            "ok": False,
            "error": "no_signal_found"
        }

    symbol = row.get("symbol", "UNKNOWN")
    side = row.get("side", "UNKNOWN")
    time_text = row.get("created_at") or row.get("signal_time") or str(row.get("candle_ts", ""))

    msg = _tg_build_signal_text(symbol=symbol, side=side, time_text=time_text)
    result = _tg_send_message(msg)

    return {
        "ok": result.get("ok", False),
        "message": msg,
        "signal": row,
        "result": result,
    }


STRATEGY_V1_LOOKBACK = 7
STRATEGY_V1_TREND_WINDOW = 5
STRATEGY_V1_EPS = 1e-9


def _strategy_v1__dedup_by_timestamp(items):
    out = []
    seen = set()
    for item in reversed(items):
        ts = None
        if isinstance(item, dict):
            ts = item.get("timestamp")
        if ts in seen:
            continue
        seen.add(ts)
        out.append(item)
    out.reverse()
    return out


def _strategy_v1__to_dict(x):
    if isinstance(x, dict):
        return dict(x)
    if hasattr(x, "model_dump"):
        try:
            return dict(x.model_dump())
        except Exception:
            pass
    if hasattr(x, "dict"):
        try:
            return dict(x.dict())
        except Exception:
            pass
    data = {}
    for key in (
        "symbol", "timestamp", "open", "high", "low", "close", "volume",
        "source", "open_time", "close_time", "age_sec"
    ):
        if hasattr(x, key):
            try:
                data[key] = getattr(x, key)
            except Exception:
                pass
    return data


def _strategy_v1__get_closed_raw():
    history_items = list(getattr(STATE, "history_closed", []) or [])
    stream_items = list(getattr(STATE, "stream_closed", []) or [])
    merged = [_strategy_v1__to_dict(x) for x in history_items + stream_items]
    merged = [x for x in merged if isinstance(x, dict) and x.get("timestamp") is not None]
    merged = _strategy_v1__dedup_by_timestamp(merged)
    merged.sort(key=lambda x: x.get("timestamp", 0))
    return merged


def _strategy_v1__compute_ha(raw_items):
    out = []
    prev_ha_open = None
    prev_ha_close = None

    for raw in raw_items:
        c = _strategy_v1__to_dict(raw)

        if not all(k in c for k in ("open", "high", "low", "close")):
            out.append(c)
            continue

        o = float(c["open"])
        h = float(c["high"])
        l = float(c["low"])
        cl = float(c["close"])

        ha_close = (o + h + l + cl) / 4.0

        if prev_ha_open is None or prev_ha_close is None:
            ha_open = (o + cl) / 2.0
        else:
            ha_open = (prev_ha_open + prev_ha_close) / 2.0

        ha_high = max(h, ha_open, ha_close)
        ha_low = min(l, ha_open, ha_close)
        ha_dir = "UP" if ha_close >= ha_open else "DOWN"

        c["ha_open"] = ha_open
        c["ha_high"] = ha_high
        c["ha_low"] = ha_low
        c["ha_close"] = ha_close
        c["ha_dir"] = ha_dir

        prev_ha_open = ha_open
        prev_ha_close = ha_close
        out.append(c)

    return out


def _strategy_v1__get_closed_ha():
    return _strategy_v1__compute_ha(_strategy_v1__get_closed_raw())


def _strategy_v1__get_forming_ha():
    current = getattr(STATE, "stream_current", None)
    if not current:
        return None

    closed_ha = _strategy_v1__get_closed_ha()
    raw_items = [_strategy_v1__to_dict(x) for x in _strategy_v1__get_closed_raw()]
    raw_items.append(_strategy_v1__to_dict(current))
    full = _strategy_v1__compute_ha(raw_items)
    if not full:
        return None

    forming = full[-1]
    last_closed_ts = closed_ha[-1]["timestamp"] if closed_ha else None
    forming["is_new_after_closed"] = (
        last_closed_ts is not None and forming.get("timestamp") != last_closed_ts
    )
    return forming


def _strategy_v1__body_size(c):
    return abs(float(c["ha_close"]) - float(c["ha_open"]))


def _strategy_v1__upper_wick(c):
    return float(c["ha_high"]) - max(float(c["ha_open"]), float(c["ha_close"]))


def _strategy_v1__lower_wick(c):
    return min(float(c["ha_open"]), float(c["ha_close"])) - float(c["ha_low"])


def _strategy_v1__is_cross(c, eps=STRATEGY_V1_EPS):
    try:
        return _strategy_v1__upper_wick(c) > eps and _strategy_v1__lower_wick(c) > eps
    except Exception:
        return False


def _strategy_v1__alternations(items):
    if len(items) < 2:
        return 0
    n = 0
    prev = items[0].get("ha_dir")
    for item in items[1:]:
        cur = item.get("ha_dir")
        if cur != prev:
            n += 1
        prev = cur
    return n


def _strategy_v1__trend_state(closed_ha):
    window = closed_ha[-STRATEGY_V1_TREND_WINDOW:] if len(closed_ha) >= 1 else []

    if len(window) < 3:
        return {
            "trend_buy": False,
            "trend_sell": False,
            "chaos": True,
            "up_count": 0,
            "down_count": 0,
            "alternations": 0,
            "net_ha_move": 0.0,
            "last2_up": 0,
            "last2_down": 0,
            "last3_up": 0,
            "last3_down": 0,
            "cross_count": 0,
            "clean_body_count": 0,
            "env_ok": False,
            "reason": "not_enough_closed_candles"
        }

    up_count = sum(1 for x in window if x.get("ha_dir") == "UP")
    down_count = sum(1 for x in window if x.get("ha_dir") == "DOWN")
    alternations = _strategy_v1__alternations(window)
    net_ha_move = float(window[-1]["ha_close"]) - float(window[0]["ha_close"])

    last2 = window[-2:]
    last3 = window[-3:]

    last2_up = sum(1 for x in last2 if x.get("ha_dir") == "UP")
    last2_down = sum(1 for x in last2 if x.get("ha_dir") == "DOWN")
    last3_up = sum(1 for x in last3 if x.get("ha_dir") == "UP")
    last3_down = sum(1 for x in last3 if x.get("ha_dir") == "DOWN")

    cross_count = sum(1 for x in window if _strategy_v1__is_cross(x))

    clean_body_count = 0
    for x in window:
        body = _strategy_v1__body_size(x)
        upper = _strategy_v1__upper_wick(x)
        lower = _strategy_v1__lower_wick(x)
        if body > (upper + lower):
            clean_body_count += 1

    env_ok = (
        alternations <= 2 and
        cross_count <= 3 and
        clean_body_count >= 1
    )

    trend_buy_base = (
        up_count >= 4 and
        net_ha_move > 0 and
        env_ok
    )

    trend_sell_base = (
        down_count >= 4 and
        net_ha_move < 0 and
        env_ok
    )

    recent_buy_push = (
        (last2_up == 2) or
        (last3_up >= 2 and float(last3[-1]["ha_close"]) >= float(last3[0]["ha_close"]))
    )

    recent_sell_push = (
        (last2_down == 2) or
        (last3_down >= 2 and float(last3[-1]["ha_close"]) <= float(last3[0]["ha_close"]))
    )

    trend_buy = trend_buy_base and not recent_sell_push
    trend_sell = trend_sell_base and not recent_buy_push

    if recent_buy_push and not recent_sell_push:
        trend_sell = False

    if recent_sell_push and not recent_buy_push:
        trend_buy = False

    chaos = (
        alternations >= 4 or
        cross_count >= 4 or
        (not env_ok and alternations >= 3) or
        (not trend_buy and not trend_sell)
    )

    reason = []
    if trend_buy:
        reason.append("trend_buy_ok")
    if trend_sell:
        reason.append("trend_sell_ok")
    if recent_buy_push:
        reason.append("recent_buy_push")
    if recent_sell_push:
        reason.append("recent_sell_push")
    if not env_ok:
        reason.append("environment_not_clean")
    if chaos:
        reason.append("chaos_or_no_trade")

    return {
        "trend_buy": trend_buy,
        "trend_sell": trend_sell,
        "chaos": chaos,
        "up_count": up_count,
        "down_count": down_count,
        "alternations": alternations,
        "net_ha_move": net_ha_move,
        "last2_up": last2_up,
        "last2_down": last2_down,
        "last3_up": last3_up,
        "last3_down": last3_down,
        "cross_count": cross_count,
        "clean_body_count": clean_body_count,
        "env_ok": env_ok,
        "reason": ",".join(reason) if reason else "neutral"
    }


def _strategy_v1__reaction_buy_ok(forming):
    if not forming:
        return False
    try:
        return (
            forming.get("ha_dir") == "UP" and
            _strategy_v1__lower_wick(forming) <= STRATEGY_V1_EPS and
            _strategy_v1__body_size(forming) > STRATEGY_V1_EPS
        )
    except Exception:
        return False


def _strategy_v1__reaction_sell_ok(forming):
    if not forming:
        return False
    try:
        return (
            forming.get("ha_dir") == "DOWN" and
            _strategy_v1__upper_wick(forming) <= STRATEGY_V1_EPS and
            _strategy_v1__body_size(forming) > STRATEGY_V1_EPS
        )
    except Exception:
        return False


def _strategy_v1__build_debug():
    closed_ha = _strategy_v1__get_closed_ha()
    forming = _strategy_v1__get_forming_ha()

    trend = _strategy_v1__trend_state(closed_ha)

    prev_candle = closed_ha[-2] if len(closed_ha) >= 2 else None
    last_candle = closed_ha[-1] if len(closed_ha) >= 1 else None

    prev_candle_is_cross = _strategy_v1__is_cross(prev_candle) if prev_candle else False
    last_candle_is_cross = _strategy_v1__is_cross(last_candle) if last_candle else False
    two_crosses = prev_candle_is_cross and last_candle_is_cross

    new_candle_started = bool(forming and forming.get("is_new_after_closed"))

    prepare_buy = bool(two_crosses and new_candle_started and _strategy_v1__reaction_buy_ok(forming))
    prepare_sell = bool(two_crosses and new_candle_started and _strategy_v1__reaction_sell_ok(forming))

    new_candle_direction_buy_ok = bool(forming and float(forming.get("close", 0)) > float(forming.get("open", 0)))
    new_candle_direction_sell_ok = bool(forming and float(forming.get("close", 0)) < float(forming.get("open", 0)))

    reaction_buy_ok = bool(new_candle_started and two_crosses and _strategy_v1__reaction_buy_ok(forming))
    reaction_sell_ok = bool(new_candle_started and two_crosses and _strategy_v1__reaction_sell_ok(forming))

    final_buy = bool(reaction_buy_ok)
    final_sell = bool(reaction_sell_ok)

    reason = []
    if trend["chaos"]:
        reason.append("chaos")
    if two_crosses:
        reason.append("two_crosses")
    if prepare_buy:
        reason.append("prepare_buy")
    if prepare_sell:
        reason.append("prepare_sell")
    if final_buy:
        reason.append("final_buy")
    if final_sell:
        reason.append("final_sell")
    if not reason:
        reason.append("no_signal")

    if final_buy:
        state = "FINAL_BUY"
    elif final_sell:
        state = "FINAL_SELL"
    elif prepare_buy:
        state = "PREPARE_BUY"
    elif prepare_sell:
        state = "PREPARE_SELL"
    elif trend["chaos"]:
        state = "CHAOS_NO_TRADE"
    elif trend["trend_buy"] and not two_crosses:
        state = "BUY_TREND_NO_CROSSES"
    elif trend["trend_sell"] and not two_crosses:
        state = "SELL_TREND_NO_CROSSES"
    elif trend["trend_buy"] and two_crosses and not new_candle_started:
        state = "BUY_WAITING_NEW_CANDLE"
    elif trend["trend_sell"] and two_crosses and not new_candle_started:
        state = "SELL_WAITING_NEW_CANDLE"
    elif trend["trend_buy"] and two_crosses and new_candle_started and not reaction_buy_ok:
        state = "BUY_WAITING_REACTION"
    elif trend["trend_sell"] and two_crosses and new_candle_started and not reaction_sell_ok:
        state = "SELL_WAITING_REACTION"
    else:
        state = "NO_SIGNAL"

    snapshot = []
    for x in closed_ha[-STRATEGY_V1_LOOKBACK:]:
        row = {
            "timestamp": x.get("timestamp"),
            "open_time": x.get("open_time"),
            "ha_open": x.get("ha_open"),
            "ha_high": x.get("ha_high"),
            "ha_low": x.get("ha_low"),
            "ha_close": x.get("ha_close"),
            "ha_dir": x.get("ha_dir"),
            "is_cross": _strategy_v1__is_cross(x),
        }
        snapshot.append(row)

    forming_out = None
    if forming:
        forming_out = {
            "timestamp": forming.get("timestamp"),
            "open_time": forming.get("open_time"),
            "close_time": forming.get("close_time"),
            "open": forming.get("open"),
            "high": forming.get("high"),
            "low": forming.get("low"),
            "close": forming.get("close"),
            "ha_open": forming.get("ha_open"),
            "ha_high": forming.get("ha_high"),
            "ha_low": forming.get("ha_low"),
            "ha_close": forming.get("ha_close"),
            "ha_dir": forming.get("ha_dir"),
            "is_new_after_closed": forming.get("is_new_after_closed"),
            "lower_wick": _strategy_v1__lower_wick(forming),
            "upper_wick": _strategy_v1__upper_wick(forming),
            "body_size": _strategy_v1__body_size(forming),
        }

    return {
        "ok": True,
        "symbol": getattr(STATE, "symbol", None),
        "active_mode": getattr(STATE, "active_mode", None),
        "trend_buy": trend["trend_buy"],
        "trend_sell": trend["trend_sell"],
        "chaos": trend["chaos"],
        "up_count": trend["up_count"],
        "down_count": trend["down_count"],
        "alternations": trend["alternations"],
        "net_ha_move": trend["net_ha_move"],
        "last2_up": trend["last2_up"],
        "last2_down": trend["last2_down"],
        "last3_up": trend["last3_up"],
        "last3_down": trend["last3_down"],
        "cross_count": trend["cross_count"],
        "clean_body_count": trend["clean_body_count"],
        "env_ok": trend["env_ok"],
        "prev_candle_is_cross": prev_candle_is_cross,
        "last_candle_is_cross": last_candle_is_cross,
        "two_crosses": two_crosses,
        "prepare_buy": prepare_buy,
        "prepare_sell": prepare_sell,
        "new_candle_started": new_candle_started,
        "new_candle_direction_buy_ok": new_candle_direction_buy_ok,
        "new_candle_direction_sell_ok": new_candle_direction_sell_ok,
        "reaction_buy_ok": reaction_buy_ok,
        "reaction_sell_ok": reaction_sell_ok,
        "final_buy": final_buy,
        "final_sell": final_sell,
        "state": state,
        "reason": ",".join(reason),
        "snapshot": snapshot,
        "forming": forming_out,
    }



STRATEGY_V1_SENT_PREPARES = set()
STRATEGY_V1_SENT_FINALS = set()
STRATEGY_V1_SENT_MULTI = set()
STRATEGY_V1_LAST_AUTO_SWITCH_TS = 0.0
STRATEGY_V1_AUTO_SWITCH_COOLDOWN_SEC = 60.0


def _strategy_v1__prepare_key(debug):
    symbol = debug.get("symbol") or "?"
    side = "BUY" if debug.get("prepare_buy") else ("SELL" if debug.get("prepare_sell") else "?")
    last_ts = None
    snap = debug.get("snapshot") or []
    if snap:
        last_ts = snap[-1].get("timestamp")
    return f"{symbol}:{last_ts}:{side}"


def _strategy_v1__send_prepare_if_needed():
    debug = _strategy_v1__build_debug()

    if not (debug.get("prepare_buy") or debug.get("prepare_sell")):
        return {
            "ok": True,
            "sent": False,
            "reason": "no_prepare_state",
            "state": debug.get("state"),
        }

    prepare_key = _strategy_v1__prepare_key(debug)
    if prepare_key in STRATEGY_V1_SENT_PREPARES:
        return {
            "ok": True,
            "sent": False,
            "reason": "already_sent",
            "prepare_key": prepare_key,
            "state": debug.get("state"),
        }

    side = "BUY" if debug.get("prepare_buy") else "SELL"
    snap = debug.get("snapshot") or []
    ts_text = "?"
    if snap:
        ts_text = snap[-1].get("open_time") or str(snap[-1].get("timestamp"))

    message = f"PREPARE\n{debug.get('symbol')}\n{side}\n{ts_text}"

    result = _telegram_send_text(message)
    sent_ok = bool(result and result.get("ok"))

    if sent_ok:
        STRATEGY_V1_SENT_PREPARES.add(prepare_key)

    return {
        "ok": True,
        "sent": sent_ok,
        "prepare_key": prepare_key,
        "message": message,
        "telegram_result": result,
        "state": debug.get("state"),
    }


def _strategy_v1__final_key(debug):
    symbol = debug.get("symbol") or "?"
    side = "BUY" if debug.get("final_buy") else ("SELL" if debug.get("final_sell") else "?")
    forming = debug.get("forming") or {}
    ts = forming.get("timestamp") or "?"
    return f"{symbol}:{ts}:{side}"


def _strategy_v1__send_final_if_needed():
    debug = _strategy_v1__build_debug()

    if not (debug.get("final_buy") or debug.get("final_sell")):
        return {
            "ok": True,
            "sent": False,
            "reason": "no_final_state",
            "state": debug.get("state"),
        }

    final_key = _strategy_v1__final_key(debug)
    if final_key in STRATEGY_V1_SENT_FINALS:
        return {
            "ok": True,
            "sent": False,
            "reason": "already_sent",
            "final_key": final_key,
            "state": debug.get("state"),
        }

    side = "BUY" if debug.get("final_buy") else "SELL"
    forming = debug.get("forming") or {}
    ts_text = forming.get("open_time") or str(forming.get("timestamp") or "?")

    message = f"FINAL\n{debug.get('symbol')}\n{side}\n{ts_text}"

    result = _telegram_send_text(message)
    sent_ok = bool(result and result.get("ok"))

    if sent_ok:
        STRATEGY_V1_SENT_FINALS.add(final_key)

    return {
        "ok": True,
        "sent": sent_ok,
        "final_key": final_key,
        "message": message,
        "telegram_result": result,
        "state": debug.get("state"),
    }


STRATEGY_V1_AUTO_PREPARE_RUNNING = False


def _strategy_v1__multi_signal_key(debug):
    symbol = debug.get("symbol") or "?"
    state = debug.get("state") or "?"
    forming = debug.get("forming") or {}
    snapshot = debug.get("snapshot") or []
    ts = None
    if forming and forming.get("timestamp"):
        ts = forming.get("timestamp")
    elif snapshot:
        ts = snapshot[-1].get("timestamp")
    else:
        ts = "?"
    return f"{symbol}:{state}:{ts}"


async def _strategy_v1__maybe_auto_switch_symbol():
    global _tick_task, STRATEGY_V1_LAST_AUTO_SWITCH_TS

    best = _strategy_v1__pick_best_symbol_candidate()
    now = time.time()

    if not best:
        return {"ok": True, "switched": False, "reason": "no_candidate"}

    target = best.get("symbol")
    rank = int(best.get("rank") or 0)

    if not target or target == STATE.symbol:
        return {
            "ok": True,
            "switched": False,
            "reason": "already_active_or_missing",
            "best": best,
        }

    if rank <= 0:
        return {
            "ok": True,
            "switched": False,
            "reason": "rank_not_positive",
            "best": best,
        }

    if (now - float(STRATEGY_V1_LAST_AUTO_SWITCH_TS or 0.0)) < STRATEGY_V1_AUTO_SWITCH_COOLDOWN_SEC:
        return {
            "ok": True,
            "switched": False,
            "reason": "cooldown",
            "best": best,
        }

    old_symbol = STATE.symbol
    STATE.symbol = target

    ss = _get_symbol_state(target)
    ss.stream_current = None
    ss.stream_closed = []
    ss.stream_age_sec = None
    ss.active_mode = "HISTORY"

    STATE.stream_current = None
    STATE.stream_closed = []
    STATE.stream_age_sec = None
    STATE.active_mode = "HISTORY"

    tf = STATE.tick_feed
    tf.last_tick_event = None
    tf.last_tick_ts_raw = None
    tf.last_tick_ts_used = None
    tf.last_tick_local_ts = None
    tf.last_tick_age_sec = None
    tf.last_price = None
    tf.warmup_active = False
    tf.warmup_until_open_ts = None
    tf.warmup_note = "auto_switch_reset"
    tf.asset_id_for_symbol = None

    if _tick_task is not None:
        _tick_task.cancel()
        try:
            await asyncio.gather(_tick_task, return_exceptions=True)
        except Exception:
            pass
        _tick_task = None

    if PO_USE_PW:
        _tick_task = asyncio.create_task(_tick_feed_playwright_ws())

    STRATEGY_V1_LAST_AUTO_SWITCH_TS = now

    try:
        _update_hybrid_choice()
    except Exception:
        pass

    return {
        "ok": True,
        "switched": True,
        "old_symbol": old_symbol,
        "active_symbol": STATE.symbol,
        "best": best,
    }


def _strategy_v1__scan_and_send_multi_signals():
    old_symbol = STATE.symbol
    results = []

    try:
        for sym in list(getattr(STATE, "symbols", []) or []):
            STATE.symbol = sym
            debug = _strategy_v1__build_debug()
            state = debug.get("state") or ""

            is_prepare = state in ("PREPARE_BUY", "PREPARE_SELL")
            is_final = state in ("FINAL_BUY", "FINAL_SELL")

            if not (is_prepare or is_final):
                results.append({
                    "symbol": sym,
                    "sent": False,
                    "reason": "no_signal_state",
                    "state": state,
                })
                continue

            msg_key = _strategy_v1__multi_signal_key(debug)
            if msg_key in STRATEGY_V1_SENT_MULTI:
                results.append({
                    "symbol": sym,
                    "sent": False,
                    "reason": "already_sent",
                    "state": state,
                    "key": msg_key,
                })
                continue

            side = "BUY" if ("BUY" in state) else "SELL"
            header = "FINAL" if is_final else "PREPARE"

            ts_text = "?"
            forming = debug.get("forming") or {}
            snapshot = debug.get("snapshot") or []
            if is_final and forming:
                ts_text = forming.get("open_time") or str(forming.get("timestamp") or "?")
            elif snapshot:
                ts_text = snapshot[-1].get("open_time") or str(snapshot[-1].get("timestamp") or "?")

            message = f"{header}\n{sym}\n{side}\n{ts_text}"
            result = _telegram_send_text(message)
            sent_ok = bool(result and result.get("ok"))

            if sent_ok:
                STRATEGY_V1_SENT_MULTI.add(msg_key)

            results.append({
                "symbol": sym,
                "sent": sent_ok,
                "state": state,
                "key": msg_key,
                "message": message,
                "telegram_result": result,
            })

        return {
            "ok": True,
            "items": results,
        }
    finally:
        STATE.symbol = old_symbol


async def _strategy_v1__auto_prepare_tick():
    try:
        switch_result = {"ok": True, "switched": False, "reason": "temporarily_disabled"}
        prepare_result = _strategy_v1__send_prepare_if_needed()
        final_result = _strategy_v1__send_final_if_needed()
        multi_result = _strategy_v1__scan_and_send_multi_signals()
        return {
            "ok": True,
            "switch": switch_result,
            "prepare": prepare_result,
            "final": final_result,
            "multi": multi_result,
        }
    except Exception as e:
        return {
            "ok": False,
            "error": f"auto_prepare_tick_failed: {e}",
        }


def _strategy_v1__auto_prepare_loop():
    global STRATEGY_V1_AUTO_PREPARE_RUNNING
    if STRATEGY_V1_AUTO_PREPARE_RUNNING:
        return
    STRATEGY_V1_AUTO_PREPARE_RUNNING = True

    def _runner():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        while True:
            try:
                loop.run_until_complete(_strategy_v1__auto_prepare_tick())
            except Exception:
                pass
            time.sleep(1)

    t = threading.Thread(target=_runner, name="strategy-v1-auto-prepare", daemon=True)
    t.start()


@app.on_event("startup")
def _strategy_v1__startup_auto_prepare():
    _strategy_v1__auto_prepare_loop()

@app.get("/api/strategy/debug")
def api_strategy_debug():
    data = _strategy_v1__build_debug()
    data["prepare_key"] = _strategy_v1__prepare_key(data) if (data.get("prepare_buy") or data.get("prepare_sell")) else None
    return data


@app.get("/api/strategy/debug_symbol")
def api_strategy_debug_symbol(symbol: str):
    old_symbol = STATE.symbol
    try:
        STATE.symbol = symbol
        data = _strategy_v1__build_debug()
        data["requested_symbol"] = symbol
        data["prepare_key"] = _strategy_v1__prepare_key(data) if (data.get("prepare_buy") or data.get("prepare_sell")) else None
        return data
    finally:
        STATE.symbol = old_symbol


@app.post("/api/strategy/prepare_check")
def api_strategy_prepare_check():
    return _strategy_v1__send_prepare_if_needed()
